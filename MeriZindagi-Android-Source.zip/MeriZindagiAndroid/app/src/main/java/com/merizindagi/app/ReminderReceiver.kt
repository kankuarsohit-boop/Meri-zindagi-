package com.merizindagi.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import java.util.Calendar
import java.util.Date

object ReminderScheduler {
    const val CHANNEL_ID = "merizindagi_reminders"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = android.app.NotificationChannel(
                CHANNEL_ID,
                "MeriZindagi रिमाइंडर",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "बिल, EMI, दस्तावेज़ और परिवार के कामों की याद दिलाने के लिए"
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun schedule(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context,
            900,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pending)
        } else {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pending)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        ReminderScheduler.createChannel(context)
        val prefs = context.getSharedPreferences("merizindagi_data", Context.MODE_PRIVATE)
        val raw = prefs.getString("entries", "[]") ?: "[]"
        val dueTitles = mutableListOf<String>()
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val tomorrow = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }

        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val due = item.optLong("dueDate")
                val dueDay = Calendar.getInstance().apply {
                    time = Date(due)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (dueDay.timeInMillis == today.timeInMillis ||
                    dueDay.timeInMillis == tomorrow.timeInMillis
                ) {
                    val whenText = if (dueDay.timeInMillis == today.timeInMillis) "आज" else "कल"
                    dueTitles.add("${item.optString("title")} ($whenText)")
                }
            }
        } catch (_: Exception) {
            // No reminder is shown if local data cannot be read.
        }

        if (dueTitles.isNotEmpty()) {
            val openApp = PendingIntent.getActivity(
                context,
                901,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val text = dueTitles.take(4).joinToString(" • ")
            val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(context, ReminderScheduler.CHANNEL_ID)
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(context)
            }
            val notification = builder
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("MeriZindagi: आपका रिमाइंडर")
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(dueTitles.joinToString("\n")))
                .setAutoCancel(true)
                .setContentIntent(openApp)
                .build()

            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            try {
                manager.notify(9001, notification)
            } catch (_: SecurityException) {
                // Notification permission may not have been granted.
            }
        }

        ReminderScheduler.schedule(context)
    }
}
