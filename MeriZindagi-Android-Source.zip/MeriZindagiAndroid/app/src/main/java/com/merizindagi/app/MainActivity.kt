package com.merizindagi.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class FamilyEntry(
    val id: Long,
    val type: String,
    val title: String,
    val detail: String,
    val dueDate: Long
)

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("merizindagi_data", MODE_PRIVATE) }
    private val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale("hi", "IN"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderScheduler.createChannel(this)
        askNotificationPermission()
        ReminderScheduler.schedule(this)
        render()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun loadEntries(): MutableList<FamilyEntry> {
        val result = mutableListOf<FamilyEntry>()
        val raw = prefs.getString("entries", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(
                    FamilyEntry(
                        obj.optLong("id"),
                        obj.optString("type"),
                        obj.optString("title"),
                        obj.optString("detail"),
                        obj.optLong("dueDate")
                    )
                )
            }
        } catch (_: Exception) {
            // Ignore damaged local data and start with an empty list.
        }
        return result
    }

    private fun saveEntries(entries: List<FamilyEntry>) {
        val array = JSONArray()
        entries.forEach {
            array.put(
                JSONObject()
                    .put("id", it.id)
                    .put("type", it.type)
                    .put("title", it.title)
                    .put("detail", it.detail)
                    .put("dueDate", it.dueDate)
            )
        }
        prefs.edit().putString("entries", array.toString()).apply()
    }

    private fun render() {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        scroll.addView(content)
        setContentView(scroll)

        addText("MeriZindagi", 28f, true, 0xFF172554.toInt())
        addText("आपके परिवार और जरूरी कामों का साथी", 15f, false, 0xFF475569.toInt())
        addSpace(16)

        val entries = loadEntries()
        val bills = entries.count { it.type == "बिल / EMI" }
        val docs = entries.count { it.type == "दस्तावेज़" }
        val tasks = entries.count { it.type == "परिवार का काम" }
        addText("आपका डैशबोर्ड", 19f, true, 0xFF111827.toInt())
        addText("बिल/EMI: $bills    दस्तावेज़: $docs    काम: $tasks", 15f, true, 0xFF334155.toInt())
        addSpace(12)

        addActionButton("＋ बिल / EMI जोड़ें") { showAddDialog("बिल / EMI") }
        addActionButton("＋ दस्तावेज़ जोड़ें") { showAddDialog("दस्तावेज़") }
        addActionButton("＋ परिवार का काम जोड़ें") { showAddDialog("परिवार का काम") }
        addSpace(8)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
            if (!alarmManager.canScheduleExactAlarms()) {
                addText("रोज़ सुबह 9 बजे समय पर रिमाइंडर के लिए अनुमति दें:", 14f, false, 0xFF92400E.toInt())
                addActionButton("9 बजे रिमाइंडर की अनुमति दें") {
                    try {
                        startActivity(
                            Intent(
                                Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                Uri.parse("package:$packageName")
                            )
                        )
                    } catch (_: Exception) {
                        Toast.makeText(this, "सेटिंग में अलार्म अनुमति चालू करें", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        addSpace(14)
        addText("आपकी सूची", 20f, true, 0xFF111827.toInt())
        if (entries.isEmpty()) {
            addText("अभी कोई जानकारी नहीं है। ऊपर के बटन से पहली एंट्री जोड़ें।", 14f, false, 0xFF64748B.toInt())
        } else {
            entries.sortedBy { it.dueDate }.forEach { entry -> addEntryCard(entry) }
        }

        addSpace(14)
        addText("नोट: आपकी जानकारी अभी इसी मोबाइल में सेव होती है। ऐप का डेटा हटाने पर जानकारी मिट सकती है।", 12f, false, 0xFF64748B.toInt())
    }

    private fun showAddDialog(type: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val titleInput = EditText(this).apply {
            hint = when (type) {
                "बिल / EMI" -> "बिल या EMI का नाम"
                "दस्तावेज़" -> "दस्तावेज़ का नाम"
                else -> "काम का नाम"
            }
        }
        val detailInput = EditText(this).apply {
            hint = when (type) {
                "बिल / EMI" -> "रकम / जरूरी जानकारी"
                "दस्तावेज़" -> "नंबर या दूसरी जानकारी (वैकल्पिक)"
                else -> "किसके लिए / जानकारी (वैकल्पिक)"
            }
        }
        var selectedDate = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val dateLabel = TextView(this).apply {
            text = "तारीख: ${dateFormat.format(Date(selectedDate))}"
            textSize = 15f
            setPadding(0, dp(12), 0, dp(8))
        }
        val chooseDate = Button(this).apply {
            text = "तारीख चुनें"
            setOnClickListener {
                val c = Calendar.getInstance().apply { timeInMillis = selectedDate }
                DatePickerDialog(
                    this@MainActivity,
                    { _, year, month, day ->
                        c.set(year, month, day, 9, 0, 0)
                        c.set(Calendar.MILLISECOND, 0)
                        selectedDate = c.timeInMillis
                        dateLabel.text = "तारीख: ${dateFormat.format(Date(selectedDate))}"
                    },
                    c.get(Calendar.YEAR),
                    c.get(Calendar.MONTH),
                    c.get(Calendar.DAY_OF_MONTH)
                ).show()
            }
        }
        box.addView(titleInput)
        box.addView(detailInput)
        box.addView(dateLabel)
        box.addView(chooseDate)

        AlertDialog.Builder(this)
            .setTitle("$type जोड़ें")
            .setView(box)
            .setNegativeButton("रद्द करें", null)
            .setPositiveButton("सेव करें") { _, _ ->
                val title = titleInput.text.toString().trim()
                if (title.isEmpty()) {
                    Toast.makeText(this, "पहले नाम लिखें", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val list = loadEntries()
                list.add(
                    FamilyEntry(
                        System.currentTimeMillis(),
                        type,
                        title,
                        detailInput.text.toString().trim(),
                        selectedDate
                    )
                )
                saveEntries(list)
                render()
                Toast.makeText(this, "जानकारी सेव हो गई", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun addEntryCard(entry: FamilyEntry) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(10))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val heading = TextView(this).apply {
            text = "${entry.type}  •  ${entry.title}"
            textSize = 17f
            setTextColor(0xFF1E293B.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val detail = TextView(this).apply {
            text = (if (entry.detail.isBlank()) "" else "${entry.detail}\n") +
                "तारीख: ${dateFormat.format(Date(entry.dueDate))}"
            textSize = 14f
            setTextColor(0xFF475569.toInt())
            setPadding(0, dp(5), 0, dp(4))
        }
        val delete = Button(this).apply {
            text = "हटाएँ"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage("क्या इस जानकारी को हटाना चाहते हैं?")
                    .setNegativeButton("नहीं", null)
                    .setPositiveButton("हाँ") { _, _ ->
                        saveEntries(loadEntries().filterNot { it.id == entry.id })
                        render()
                    }
                    .show()
            }
        }
        card.addView(heading)
        card.addView(detail)
        card.addView(delete)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) }
        content.addView(card, params)
    }

    private fun addActionButton(label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setOnClickListener { action() }
        }
        content.addView(
            button,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(5) }
        )
    }

    private fun addText(value: String, size: Float, bold: Boolean, color: Int) {
        val view = TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }
        content.addView(view)
    }

    private fun addSpace(dpValue: Int) {
        val view = View(this)
        content.addView(view, LinearLayout.LayoutParams(1, dp(dpValue)))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
