MeriZindagi Android App - Version 3.0

Features in this update:
- Hindi / English language selector (core screens and settings)
- Dark / Light appearance
- Document entries can include a photo and due/expiry date
- Bills and EMI tracking with amount, notes and date
- Family task entries with assigned-to notes
- 9 AM daily reminder notification for items due today or tomorrow
- 4-digit app PIN lock
- Search entries in Bills, Documents and Family lists
- Export entries as a PDF report
- Create and restore a JSON backup file
- Premium navy-blue and gold visual theme and launcher icon

Important notes:
- Data is stored locally on this phone. Back up before uninstalling or changing phones.
- Backup includes saved entries and document photo URI references; photo availability after moving to another phone depends on the original photo provider.
- Premium payments, online family sync, and cloud backup are not activated in this build.
- Android notification and exact-alarm permissions must be allowed for scheduled reminders. Android battery restrictions may affect delivery on some phones.
- This ZIP is Android source code, not an APK. GitHub Actions builds the APK.

Build instructions for the existing GitHub repository:
1. Replace the repository's existing MeriZindagi-Premium-Modern-Android-v2.zip with this ZIP, keeping the exact same filename.
2. Commit the upload directly to main.
3. Open Actions -> Build MeriZindagi Android APK -> Run workflow.
4. Open the newest successful green run.
5. At the bottom, open Artifacts and download MeriZindagi-APK.
6. Extract the artifact ZIP and install app-debug.apk on your Android phone.
