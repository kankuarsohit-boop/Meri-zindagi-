package com.merizindagi.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Entry(
    val id: Long,
    val type: String,
    val title: String,
    val detail: String,
    val amount: String,
    val date: Long,
    val done: Boolean
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("merizindagi_data", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var nav: LinearLayout
    private var selectedTab = "होम"
    private val bg = Color.rgb(9, 15, 31)
    private val panel = Color.rgb(19, 29, 51)
    private val panel2 = Color.rgb(25, 38, 65)
    private val white = Color.rgb(241, 246, 255)
    private val muted = Color.rgb(153, 169, 198)
    private val cyan = Color.rgb(69, 220, 207)
    private val purple = Color.rgb(155, 125, 255)
    private val orange = Color.rgb(255, 183, 91)
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale("hi", "IN"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        ReminderScheduler.createChannel(this)
        askNotificationPermission()
        ReminderScheduler.schedule(this)
        render()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun load(): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val a = JSONArray(prefs.getString("entries", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Entry(o.optLong("id"), o.optString("type"), o.optString("title"),
                    o.optString("detail"), o.optString("amount"), o.optLong("date"), o.optBoolean("done")))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun save(list: List<Entry>) {
        val a = JSONArray()
        list.forEach { e ->
            a.put(JSONObject().put("id", e.id).put("type", e.type).put("title", e.title)
                .put("detail", e.detail).put("amount", e.amount).put("date", e.date).put("done", e.done))
        }
        prefs.edit().putString("entries", a.toString()).apply()
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(22))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(panel, 22)
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(70)).apply {
            setMargins(dp(14), dp(4), dp(14), dp(12))
        })
        setContentView(root)
        when (selectedTab) {
            "होम" -> home()
            "बिल" -> listing("बिल / EMI")
            "दस्तावेज़" -> listing("दस्तावेज़")
            "परिवार" -> listing("परिवार का काम")
            "प्रोफाइल" -> profile()
        }
        buildNav()
    }

    private fun home() {
        val list = load()
        val bills = list.filter { it.type == "बिल / EMI" }
        val docs = list.filter { it.type == "दस्तावेज़" }
        val tasks = list.filter { it.type == "परिवार का काम" }
        val pending = list.count { !it.done }
        text("नमस्ते 👋", 14f, muted, false)
        text("MeriZindagi", 30f, white, true)
        text("आपकी ज़िंदगी, अब और व्यवस्थित", 14f, muted, false)
        space(18)
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(37, 69, 112), Color.rgb(75, 57, 137))).apply { cornerRadius = dp(24).toFloat() }
        }
        hero.addView(TextView(this).apply { text = "आज का ओवरव्यू"; textSize = 14f; setTextColor(0xFFDDE7FF.toInt()) })
        hero.addView(TextView(this).apply {
            text = "$pending"; textSize = 42f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
            setPadding(0, dp(4), 0, 0)
        })
        hero.addView(TextView(this).apply { text = "पेंडिंग काम और रिमाइंडर"; textSize = 14f; setTextColor(0xFFDDE7FF.toInt()) })
        spaceIn(hero, 14)
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        quick.addView(chip("＋ नया जोड़ें") { showAddDialog(null) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        quick.addView(chip("⏰ रिमाइंडर") { openAlarmSettings() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(8) })
        hero.addView(quick)
        body.addView(hero, match().apply { bottomMargin = dp(18) })

        text("आपका मैनेजर", 20f, white, true)
        text("ज़रूरी चीज़ें एक ही जगह", 13f, muted, false)
        space(10)
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(statCard("बिल / EMI", bills.size.toString(), "भुगतान ट्रैक करें", cyan, "₹") { selectedTab = "बिल"; render() },
            LinearLayout.LayoutParams(0, dp(128), 1f))
        row1.addView(statCard("दस्तावेज़", docs.size.toString(), "एक्सपायरी याद रखें", purple, "▣") { selectedTab = "दस्तावेज़"; render() },
            LinearLayout.LayoutParams(0, dp(128), 1f).apply { leftMargin = dp(10) })
        body.addView(row1)
        space(10)
        body.addView(statCard("परिवार के काम", tasks.size.toString(), "काम बाँटें और पूरा करें", orange, "✓") {
            selectedTab = "परिवार"; render()
        }, match().apply { height = dp(112) })

        space(20)
        text("आने वाले रिमाइंडर", 20f, white, true)
        text("तारीख के अनुसार आपकी सूची", 13f, muted, false)
        space(8)
        val upcoming = list.filter { !it.done }.sortedBy { it.date }.take(4)
        if (upcoming.isEmpty()) emptyState("अभी कोई पेंडिंग रिमाइंडर नहीं", "＋ बटन से बिल, दस्तावेज़ या काम जोड़ें")
        else upcoming.forEach { entryCard(it, compact = true) }
        space(12)
        text("त्वरित जोड़ें", 18f, white, true)
        val addRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("बिल / EMI", "दस्तावेज़", "परिवार का काम").forEach { type ->
            addRow.addView(chip("+ ${type.replace("परिवार का काम", "काम")}") { showAddDialog(type) },
                LinearLayout.LayoutParams(0, dp(46), 1f).apply { if (type != "बिल / EMI") leftMargin = dp(5) })
        }
        body.addView(addRow)
    }

    private fun listing(type: String) {
        val heading = if (type == "बिल / EMI") "बिल और EMI" else if (type == "दस्तावेज़") "मेरे दस्तावेज़" else "परिवार के काम"
        text(heading, 27f, white, true)
        text(when (type) {
            "बिल / EMI" -> "भुगतान और किस्तों पर नज़र रखें"
            "दस्तावेज़" -> "जरूरी दस्तावेज़ और उनकी तारीखें"
            else -> "परिवार के काम व्यवस्थित करें"
        }, 14f, muted, false)
        space(14)
        button("＋ नया ${if (type == "परिवार का काम") "काम" else if (type == "दस्तावेज़") "दस्तावेज़" else "बिल / EMI"} जोड़ें", cyan) {
            showAddDialog(type)
        }
        space(12)
        val entries = load().filter { it.type == type }.sortedBy { it.date }
        if (entries.isEmpty()) emptyState("अभी कुछ जोड़ा नहीं गया", "ऊपर के बटन से पहली एंट्री जोड़ें")
        else entries.forEach { entryCard(it, compact = false) }
    }

    private fun profile() {
        text("सेटिंग्स", 27f, white, true)
        text("MeriZindagi ऐप", 14f, muted, false)
        space(18)
        infoCard("⏰  सुबह 9 बजे रिमाइंडर", "रिमाइंडर चालू रखने के लिए नोटिफिकेशन अनुमति दें।")
        button("अलार्म अनुमति सेटिंग खोलें", purple) { openAlarmSettings() }
        space(10)
        infoCard("🔒  आपकी जानकारी", "इस वर्जन में डेटा इसी फोन में सेव होता है। फोन बदलने या ऐप डेटा हटाने पर डेटा खो सकता है।")
        infoCard("⭐  Premium", "Premium सदस्यता, क्लाउड बैकअप और परिवार के साथ सिंक आगे के अपडेट में जोड़े जा सकते हैं।")
        infoCard("संस्करण 2.0", "Premium Modern डिज़ाइन • हिंदी")
    }

    private fun entryCard(e: Entry, compact: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(12))
            background = rounded(panel, 18)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val label = TextView(this).apply {
            text = when (e.type) { "बिल / EMI" -> "₹  BILL / EMI"; "दस्तावेज़" -> "▣  DOCUMENT"; else -> "✓  FAMILY TASK" }
            textSize = 10f; setTextColor(cyan); setTypeface(null, Typeface.BOLD)
        }
        val title = TextView(this).apply {
            text = e.title; textSize = 16f; setTextColor(white); setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(4), 0, 0)
        }
        left.addView(label); left.addView(title)
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        val status = TextView(this).apply {
            text = if (e.done) "पूरा" else "पेंडिंग"
            textSize = 11f; setTextColor(if (e.done) cyan else orange)
            setPadding(dp(9), dp(6), dp(9), dp(6)); background = rounded(panel2, 30)
        }
        top.addView(status)
        card.addView(top)
        val details = listOf(e.amount.takeIf { it.isNotBlank() }?.let { "₹ $it" },
            e.detail.takeIf { it.isNotBlank() }, dateFmt.format(Date(e.date))).filterNotNull().joinToString("  •  ")
        card.addView(TextView(this).apply {
            text = details; textSize = 12f; setTextColor(muted); setPadding(0, dp(8), 0, 0)
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        val doneBtn = TextView(this).apply {
            text = if (e.done) "फिर खोलें" else "पूरा करें"; textSize = 12f; setTextColor(cyan)
            setPadding(dp(10), dp(9), dp(10), dp(4))
            setOnClickListener {
                val updated = load().map { if (it.id == e.id) it.copy(done = !it.done) else it }
                save(updated); render()
            }
        }
        val deleteBtn = TextView(this).apply {
            text = "हटाएँ"; textSize = 12f; setTextColor(0xFFFF8C9A.toInt())
            setPadding(dp(10), dp(9), dp(2), dp(4))
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("इस एंट्री को हटाएँ?")
                    .setNegativeButton("रद्द", null).setPositiveButton("हटाएँ") { _, _ ->
                        save(load().filterNot { it.id == e.id }); render()
                    }.show()
            }
        }
        actions.addView(doneBtn); actions.addView(deleteBtn); card.addView(actions)
        body.addView(card, match().apply { bottomMargin = dp(9) })
    }

    private fun showAddDialog(preselected: String?) {
        val types = arrayOf("बिल / EMI", "दस्तावेज़", "परिवार का काम")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        val typeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, types)
            if (preselected != null) setSelection(types.indexOf(preselected).coerceAtLeast(0))
        }
        val title = EditText(this).apply { hint = "नाम लिखें (जैसे बिजली बिल)"; setSingleLine(true) }
        val amount = EditText(this).apply { hint = "रकम (वैकल्पिक)"; inputType = 2; setSingleLine(true) }
        val detail = EditText(this).apply { hint = "नोट / किसके लिए (वैकल्पिक)"; setSingleLine(true) }
        var due = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val dateText = TextView(this).apply { text = "तारीख: ${dateFmt.format(Date(due))}"; setTextColor(Color.DKGRAY); setPadding(0, dp(10), 0, dp(4)) }
        val dateBtn = Button(this).apply {
            text = "तारीख चुनें"
            setOnClickListener {
                val c = Calendar.getInstance().apply { timeInMillis = due }
                DatePickerDialog(this@MainActivity, { _, y, m, d ->
                    c.set(y, m, d, 9, 0, 0); c.set(Calendar.MILLISECOND, 0)
                    due = c.timeInMillis; dateText.text = "तारीख: ${dateFmt.format(Date(due))}"
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
            }
        }
        box.addView(typeSpinner); box.addView(title); box.addView(amount); box.addView(detail); box.addView(dateText); box.addView(dateBtn)
        AlertDialog.Builder(this).setTitle("नई एंट्री जोड़ें").setView(box)
            .setNegativeButton("रद्द", null)
            .setPositiveButton("सेव करें") { _, _ ->
                val name = title.text.toString().trim()
                if (name.isBlank()) { Toast.makeText(this, "नाम लिखना जरूरी है", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val type = typeSpinner.selectedItem.toString()
                val list = load()
                list.add(Entry(System.currentTimeMillis(), type, name, detail.text.toString().trim(),
                    amount.text.toString().trim(), due, false))
                save(list); render()
                Toast.makeText(this, "सेव हो गया", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun buildNav() {
        val items = listOf("होम" to "⌂", "बिल" to "₹", "दस्तावेज़" to "▣", "परिवार" to "✓", "प्रोफाइल" to "☰")
        items.forEach { (name, icon) ->
            val active = selectedTab == name
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(dp(3), dp(5), dp(3), dp(3))
                setOnClickListener { selectedTab = name; render() }
            }
            col.addView(TextView(this).apply {
                text = icon; textSize = 21f; gravity = Gravity.CENTER
                setTextColor(if (active) cyan else muted)
            })
            col.addView(TextView(this).apply {
                text = name; textSize = 10f; gravity = Gravity.CENTER
                setTextColor(if (active) cyan else muted)
            })
            nav.addView(col, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun statCard(title: String, count: String, sub: String, accent: Int, icon: String, action: () -> Unit): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(12))
            background = rounded(panel, 18); setOnClickListener { action() }
        }
        c.addView(TextView(this).apply { text = icon; textSize = 20f; setTextColor(accent) })
        c.addView(TextView(this).apply { text = count; textSize = 25f; setTypeface(null, Typeface.BOLD); setTextColor(white); setPadding(0, dp(3), 0, 0) })
        c.addView(TextView(this).apply { text = title; textSize = 13f; setTextColor(white) })
        c.addView(TextView(this).apply { text = sub; textSize = 10f; setTextColor(muted); setPadding(0, dp(3), 0, 0) })
        return c
    }

    private fun infoCard(title: String, desc: String) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = rounded(panel, 18) }
        c.addView(TextView(this).apply { text = title; textSize = 16f; setTextColor(white); setTypeface(null, Typeface.BOLD) })
        c.addView(TextView(this).apply { text = desc; textSize = 13f; setTextColor(muted); setPadding(0, dp(7), 0, 0) })
        body.addView(c, match().apply { bottomMargin = dp(10) })
    }

    private fun emptyState(title: String, desc: String) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(26), dp(20), dp(26)); background = rounded(panel, 18) }
        c.addView(TextView(this).apply { text = "✦"; textSize = 28f; setTextColor(purple); gravity = Gravity.CENTER })
        c.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(white); gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD) })
        c.addView(TextView(this).apply { text = desc; textSize = 12f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
        body.addView(c, match())
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) {
        body.addView(TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        })
    }

    private fun chip(label: String, action: () -> Unit): View {
        val t = TextView(this).apply {
            text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(white)
            background = rounded(0x334FFFFFF, 30); setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { action() }
        }
        return t
    }

    private fun button(label: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply { text = label; isAllCaps = false; setTextColor(bg); setBackground(rounded(color, 14)); setOnClickListener { action() } }
        body.addView(b, match())
    }

    private fun openAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
                return
            }
        }
        Toast.makeText(this, "रिमाइंडर शेड्यूल करने की अनुमति उपलब्ध है", Toast.LENGTH_LONG).show()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun match() = LinearLayout.LayoutParams(-1, -2)
    private fun space(v: Int) { body.addView(View(this), LinearLayout.LayoutParams(1, dp(v))) }
    private fun spaceIn(parent: LinearLayout, v: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(v))) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
