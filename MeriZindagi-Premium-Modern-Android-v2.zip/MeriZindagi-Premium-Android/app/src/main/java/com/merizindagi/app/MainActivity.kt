package com.merizindagi.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Entry(
    val id: Long,
    val type: String,
    val title: String,
    val detail: String,
    val amount: String,
    val date: Long,
    val done: Boolean,
    val photoUri: String = ""
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("merizindagi_data", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var nav: LinearLayout
    private var selectedTab = "होम"
    private var bg = Color.rgb(9, 15, 31)
    private var panel = Color.rgb(19, 29, 51)
    private var panel2 = Color.rgb(25, 38, 65)
    private var white = Color.rgb(241, 246, 255)
    private var muted = Color.rgb(153, 169, 198)
    private val cyan = Color.rgb(198, 164, 92)
    private val purple = Color.rgb(155, 125, 255)
    private val orange = Color.rgb(255, 183, 91)
    private var pendingPhotoUri = ""
    private var photoStatus: TextView? = null
    private val PICK_PHOTO = 501
    private val BACKUP_CREATE = 502
    private val BACKUP_OPEN = 503
    private val PDF_CREATE = 504
    private val dateFmt get() = SimpleDateFormat("dd MMM yyyy", if (prefs.getString("language", "hi") == "en") Locale.ENGLISH else Locale("hi", "IN"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyTheme()
        ReminderScheduler.createChannel(this)
        askNotificationPermission()
        ReminderScheduler.schedule(this)
        render()
        if (prefs.getString("app_pin", "").orEmpty().isNotBlank()) showPinDialog()
    }

    private fun applyTheme() {
        val light = prefs.getBoolean("light_theme", false)
        bg = if (light) Color.rgb(244, 246, 250) else Color.rgb(9, 15, 31)
        panel = if (light) Color.WHITE else Color.rgb(19, 29, 51)
        panel2 = if (light) Color.rgb(231, 236, 244) else Color.rgb(25, 38, 65)
        white = if (light) Color.rgb(24, 32, 48) else Color.rgb(241, 246, 255)
        muted = if (light) Color.rgb(94, 108, 130) else Color.rgb(153, 169, 198)
        window.statusBarColor = bg; window.navigationBarColor = bg; window.decorView.systemUiVisibility = if (light) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun load(): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val a = JSONArray(prefs.getString("entries", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Entry(o.optLong("id"), o.optString("type"), o.optString("title"),
                    o.optString("detail"), o.optString("amount"), o.optLong("date"), o.optBoolean("done"), o.optString("photoUri")))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun save(list: List<Entry>) {
        val a = JSONArray()
        list.forEach { e ->
            a.put(JSONObject().put("id", e.id).put("type", e.type).put("title", e.title)
                .put("detail", e.detail).put("amount", e.amount).put("date", e.date).put("done", e.done).put("photoUri", e.photoUri))
        }
        prefs.edit().putString("entries", a.toString()).apply()
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(22))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(panel, 22)
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(70)).apply {
            setMargins(dp(14), dp(4), dp(14), dp(12))
        })
        setContentView(root)
        when (selectedTab) {
            "होम" -> home()
            "बिल" -> listing("बिल / EMI")
            "दस्तावेज़" -> listing("दस्तावेज़")
            "परिवार" -> listing("परिवार का काम")
            "प्रोफाइल" -> profile()
        }
        buildNav()
    }

    private fun home() {
        val list = load()
        val bills = list.filter { it.type == "बिल / EMI" }
        val docs = list.filter { it.type == "दस्तावेज़" }
        val tasks = list.filter { it.type == "परिवार का काम" }
        val pending = list.count { !it.done }
        text(if (isEnglish()) "Hello 👋" else "नमस्ते 👋", 14f, muted, false)
        text("MeriZindagi", 30f, white, true)
        text(if (isEnglish()) "Your life, beautifully organized" else "आपकी ज़िंदगी, अब और व्यवस्थित", 14f, muted, false)
        space(18)
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(37, 69, 112), Color.rgb(75, 57, 137))).apply { cornerRadius = dp(24).toFloat() }
        }
        hero.addView(TextView(this).apply { text = if (isEnglish()) "TODAY'S OVERVIEW" else "आज का ओवरव्यू"; textSize = 14f; setTextColor(0xFFDDE7FF.toInt()) })
        hero.addView(TextView(this).apply {
            text = "$pending"; textSize = 42f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
            setPadding(0, dp(4), 0, 0)
        })
        hero.addView(TextView(this).apply { text = if (isEnglish()) "Pending tasks and reminders" else "पेंडिंग काम और रिमाइंडर"; textSize = 14f; setTextColor(0xFFDDE7FF.toInt()) })
        spaceIn(hero, 14)
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        quick.addView(chip(if (isEnglish()) "＋ Add new" else "＋ नया जोड़ें") { showAddDialog(null) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        quick.addView(chip(if (isEnglish()) "⏰ Reminders" else "⏰ रिमाइंडर") { openAlarmSettings() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(8) })
        hero.addView(quick)
        body.addView(hero, match().apply { bottomMargin = dp(18) })

        text(if (isEnglish()) "Your manager" else "आपका मैनेजर", 20f, white, true)
        text(if (isEnglish()) "Everything important in one place" else "ज़रूरी चीज़ें एक ही जगह", 13f, muted, false)
        space(10)
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(statCard(if (isEnglish()) "Bills / EMI" else "बिल / EMI", bills.size.toString(), if (isEnglish()) "Track payments" else "भुगतान ट्रैक करें", cyan, "₹") { selectedTab = "बिल"; render() },
            LinearLayout.LayoutParams(0, dp(128), 1f))
        row1.addView(statCard(if (isEnglish()) "Documents" else "दस्तावेज़", docs.size.toString(), if (isEnglish()) "Track expiry dates" else "एक्सपायरी याद रखें", purple, "▣") { selectedTab = "दस्तावेज़"; render() },
            LinearLayout.LayoutParams(0, dp(128), 1f).apply { leftMargin = dp(10) })
        body.addView(row1)
        space(10)
        body.addView(statCard(if (isEnglish()) "Family tasks" else "परिवार के काम", tasks.size.toString(), if (isEnglish()) "Assign and complete tasks" else "काम बाँटें और पूरा करें", orange, "✓") {
            selectedTab = "परिवार"; render()
        }, match().apply { height = dp(112) })

        space(20)
        text(if (isEnglish()) "Upcoming reminders" else "आने वाले रिमाइंडर", 20f, white, true)
        text(if (isEnglish()) "Your list by date" else "तारीख के अनुसार आपकी सूची", 13f, muted, false)
        space(8)
        val upcoming = list.filter { !it.done }.sortedBy { it.date }.take(4)
        if (upcoming.isEmpty()) emptyState(if (isEnglish()) "No pending reminders" else "अभी कोई पेंडिंग रिमाइंडर नहीं", if (isEnglish()) "Use + to add a bill, document or task" else "＋ बटन से बिल, दस्तावेज़ या काम जोड़ें")
        else upcoming.forEach { entryCard(it, compact = true) }
        space(12)
        text(if (isEnglish()) "Quick add" else "त्वरित जोड़ें", 18f, white, true)
        val addRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("बिल / EMI", "दस्तावेज़", "परिवार का काम").forEach { type ->
            addRow.addView(chip("+ ${type.replace("परिवार का काम", "काम")}") { showAddDialog(type) },
                LinearLayout.LayoutParams(0, dp(46), 1f).apply { if (type != "बिल / EMI") leftMargin = dp(5) })
        }
        body.addView(addRow)
    }

    private fun listing(type: String) {
        val heading = if (type == "बिल / EMI") (if (isEnglish()) "Bills & EMIs" else "बिल और EMI") else if (type == "दस्तावेज़") (if (isEnglish()) "My documents" else "मेरे दस्तावेज़") else (if (isEnglish()) "Family tasks" else "परिवार के काम")
        text(heading, 27f, white, true)
        text(when (type) {
            "बिल / EMI" -> if (isEnglish()) "Track payments and installments" else "भुगतान और किस्तों पर नज़र रखें"
            "दस्तावेज़" -> if (isEnglish()) "Important documents and expiry dates" else "जरूरी दस्तावेज़ और उनकी तारीखें"
            else -> if (isEnglish()) "Organize family tasks" else "परिवार के काम व्यवस्थित करें"
        }, 14f, muted, false)
        space(14)
        button(if (isEnglish()) "＋ Add ${if (type == "परिवार का काम") "task" else if (type == "दस्तावेज़") "document" else "bill / EMI"}" else "＋ नया ${if (type == "परिवार का काम") "काम" else if (type == "दस्तावेज़") "दस्तावेज़" else "बिल / EMI"} जोड़ें", cyan) {
            showAddDialog(type)
        }
        space(12)
        val search = EditText(this).apply { hint = if (isEnglish()) "Search entries..." else "एंट्री खोजें..."; setSingleLine(true) }
        body.addView(search, match().apply { bottomMargin = dp(8) })
        val allEntries = load().filter { it.type == type }.sortedBy { it.date }
        val entries = allEntries
        if (entries.isEmpty()) emptyState(if (isEnglish()) "Nothing added yet" else "अभी कुछ जोड़ा नहीं गया", if (isEnglish()) "Use the button above to add your first entry" else "ऊपर के बटन से पहली एंट्री जोड़ें")
        else {
            val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            body.addView(holder)
            fun showMatches(q: String) {
                holder.removeAllViews()
                val found = entries.filter { it.title.contains(q, true) || it.detail.contains(q, true) }
                if (found.isEmpty()) holder.addView(TextView(this).apply { text = if (isEnglish()) "No matching entries" else "कोई एंट्री नहीं मिली"; setTextColor(muted) })
                else found.forEach { entryCardInto(holder, it) }
            }
            showMatches("")
            search.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { showMatches(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
    }

    private fun profile() {
        text(if (isEnglish()) "Settings" else "सेटिंग्स", 27f, white, true)
        text("MeriZindagi • Premium Life Manager", 14f, muted, false)
        space(18)
        infoCard("🌐  " + if (isEnglish()) "Language" else "भाषा", if (isEnglish()) "Current: English" else "वर्तमान: हिंदी")
        button(if (isEnglish()) "Change language" else "भाषा बदलें", cyan) { chooseLanguage() }
        space(8)
        infoCard("🎨  " + if (isEnglish()) "Appearance" else "दिखावट", if (prefs.getBoolean("light_theme", false)) (if (isEnglish()) "Light mode is on" else "लाइट मोड चालू है") else (if (isEnglish()) "Dark mode is on" else "डार्क मोड चालू है"))
        button(if (isEnglish()) "Toggle light / dark mode" else "लाइट / डार्क मोड बदलें", purple) {
            prefs.edit().putBoolean("light_theme", !prefs.getBoolean("light_theme", false)).apply(); applyTheme(); render()
        }
        space(8)
        infoCard("⏰  " + if (isEnglish()) "9 AM smart reminders" else "सुबह 9 बजे स्मार्ट रिमाइंडर", if (isEnglish()) "Alerts for bills, EMIs and document dates" else "बिल, EMI और दस्तावेज़ की तारीख से पहले अलर्ट")
        button(if (isEnglish()) "Notification / alarm settings" else "नोटिफिकेशन / अलार्म सेटिंग खोलें", orange) { openAlarmSettings() }
        space(8)
        infoCard("🔐  " + if (isEnglish()) "App lock" else "ऐप लॉक", if (isEnglish()) "Set a 4-digit PIN to protect your app" else "ऐप की सुरक्षा के लिए 4 अंकों का PIN लगाएँ")
        button(if (isEnglish()) "Set / change PIN" else "PIN सेट / बदलें", purple) { setPin() }
        button(if (isEnglish()) "Remove PIN" else "PIN हटाएँ", orange) { prefs.edit().remove("app_pin").apply(); toast(if (isEnglish()) "PIN removed" else "PIN हटा दिया गया") }
        space(8)
        infoCard("📄  " + if (isEnglish()) "Export report" else "रिपोर्ट एक्सपोर्ट", if (isEnglish()) "Create a PDF summary of your entries" else "अपनी एंट्री की PDF रिपोर्ट बनाएँ")
        button(if (isEnglish()) "Export PDF" else "PDF रिपोर्ट बनाएँ", cyan) { createPdf() }
        space(8)
        infoCard("☁️  " + if (isEnglish()) "Backup & restore" else "बैकअप और रिस्टोर", if (isEnglish()) "Save your data as a file or restore it later" else "अपना डेटा फाइल में सेव करें या बाद में वापस लाएँ")
        button(if (isEnglish()) "Create backup" else "बैकअप बनाएँ", cyan) { createBackup() }
        button(if (isEnglish()) "Restore backup" else "बैकअप वापस लाएँ", purple) { restoreBackup() }
        space(8)
        infoCard("⭐  Premium", if (isEnglish()) "Premium plan preview. Online sync and paid subscriptions are not activated yet." else "Premium प्लान का प्रीव्यू। ऑनलाइन सिंक और भुगतान वाली सदस्यता अभी चालू नहीं है।")
        infoCard(if (isEnglish()) "Your privacy" else "आपकी जानकारी", if (isEnglish()) "Your data is stored on this phone. Keep a backup before changing phones." else "आपकी जानकारी इसी फोन में सेव होती है। फोन बदलने से पहले बैकअप रखें।")
        infoCard("Version 3.0", "Premium Navy & Gold • MeriZindagi")
    }

    private fun isEnglish() = prefs.getString("language", "hi") == "en"
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun chooseLanguage() {
        AlertDialog.Builder(this).setTitle("Language / भाषा")
            .setSingleChoiceItems(arrayOf("हिंदी", "English"), if (isEnglish()) 1 else 0) { d, which ->
                prefs.edit().putString("language", if (which == 1) "en" else "hi").apply(); d.dismiss(); render()
            }.setNegativeButton(if (isEnglish()) "Cancel" else "रद्द", null).show()
    }

    private fun setPin() {
        val field = EditText(this).apply { hint = if (isEnglish()) "Enter 4 digit PIN" else "4 अंकों का PIN लिखें"; inputType = 2; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle(if (isEnglish()) "Set app PIN" else "ऐप PIN सेट करें").setView(field)
            .setNegativeButton(if (isEnglish()) "Cancel" else "रद्द", null)
            .setPositiveButton(if (isEnglish()) "Save" else "सेव") { _, _ ->
                val pin = field.text.toString().trim()
                if (pin.matches(Regex("\\d{4}"))) { prefs.edit().putString("app_pin", pin).apply(); toast(if (isEnglish()) "PIN saved" else "PIN सेव हो गया") }
                else toast(if (isEnglish()) "Enter exactly 4 digits" else "4 अंक का PIN लिखें")
            }.show()
    }

    private fun showPinDialog() {
        val field = EditText(this).apply { hint = "PIN"; inputType = 2; setSingleLine(true) }
        val dialog = AlertDialog.Builder(this).setTitle(if (isEnglish()) "Unlock MeriZindagi" else "MeriZindagi अनलॉक करें")
            .setMessage(if (isEnglish()) "Enter your 4-digit PIN" else "अपना 4 अंकों का PIN लिखें")
            .setView(field).setCancelable(false).setPositiveButton(if (isEnglish()) "Unlock" else "खोलें", null).create()
        dialog.setOnShowListener { dialog.getButton(-1).setOnClickListener {
            if (field.text.toString() == prefs.getString("app_pin", "")) dialog.dismiss()
            else { field.error = if (isEnglish()) "Incorrect PIN" else "गलत PIN" }
        } }
        dialog.show()
    }

    private fun createBackup() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "MeriZindagi-Backup.json") }
        startActivityForResult(i, BACKUP_CREATE)
    }
    private fun restoreBackup() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json" }
        startActivityForResult(i, BACKUP_OPEN)
    }
    private fun createPdf() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_TITLE, "MeriZindagi-Report.pdf") }
        startActivityForResult(i, PDF_CREATE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            when (requestCode) {
                PICK_PHOTO -> {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    pendingPhotoUri = uri.toString(); photoStatus?.text = if (isEnglish()) "Photo attached ✓" else "फोटो जुड़ गई ✓"
                }
                BACKUP_CREATE -> contentResolver.openOutputStream(uri)?.use { it.write(prefs.getString("entries", "[]")!!.toByteArray()) }.also { toast(if (isEnglish()) "Backup saved" else "बैकअप सेव हो गया") }
                BACKUP_OPEN -> {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "[]"
                    org.json.JSONArray(raw)
                    prefs.edit().putString("entries", raw).apply(); ReminderScheduler.schedule(this); render(); toast(if (isEnglish()) "Backup restored" else "बैकअप वापस आ गया")
                }
                PDF_CREATE -> writePdf(uri)
            }
        } catch (e: Exception) { toast((if (isEnglish()) "Could not complete: " else "काम पूरा नहीं हुआ: ") + (e.message ?: "")) }
    }

    private fun writePdf(uri: Uri) {
        val pdf = PdfDocument(); val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val paint = android.graphics.Paint().apply { color = Color.BLACK; textSize = 16f }
        var y = 50f; page.canvas.drawText("MeriZindagi - Life Manager Report", 40f, y, paint); y += 32f
        load().sortedBy { it.date }.forEach { e ->
            val line = "${e.type}: ${e.title} | ${dateFmt.format(Date(e.date))} | ${if (e.done) "Done" else "Pending"}"
            if (y > 800) return@forEach
            page.canvas.drawText(line.take(75), 40f, y, paint); y += 24f
        }
        pdf.finishPage(page); contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }; pdf.close(); toast(if (isEnglish()) "PDF exported" else "PDF बन गई")
    }

    private fun entryCard(e: Entry, compact: Boolean) = entryCardInto(body, e)

    private fun entryCardInto(parent: LinearLayout, e: Entry) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(12))
            background = rounded(panel, 18)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val label = TextView(this).apply {
            text = when (e.type) { "बिल / EMI" -> "₹  ${if (isEnglish()) "BILL / EMI" else "बिल / EMI"}"; "दस्तावेज़" -> "▣  ${if (isEnglish()) "DOCUMENT" else "दस्तावेज़"}"; else -> "✓  ${if (isEnglish()) "FAMILY TASK" else "परिवार का काम"}" }
            textSize = 10f; setTextColor(cyan); setTypeface(null, Typeface.BOLD)
        }
        val title = TextView(this).apply {
            text = e.title; textSize = 16f; setTextColor(white); setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(4), 0, 0)
        }
        left.addView(label); left.addView(title)
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        val status = TextView(this).apply {
            text = if (e.done) (if (isEnglish()) "Done" else "पूरा") else (if (isEnglish()) "Pending" else "पेंडिंग")
            textSize = 11f; setTextColor(if (e.done) cyan else orange)
            setPadding(dp(9), dp(6), dp(9), dp(6)); background = rounded(panel2, 30)
        }
        top.addView(status)
        card.addView(top)
        if (e.photoUri.isNotBlank()) {
            try {
                val thumb = ImageView(this).apply { setImageURI(Uri.parse(e.photoUri)); scaleType = ImageView.ScaleType.CENTER_CROP }
                card.addView(thumb, LinearLayout.LayoutParams(dp(92), dp(72)).apply { topMargin = dp(8) })
            } catch (_: Exception) {}
        }
        val details = listOf(e.amount.takeIf { it.isNotBlank() }?.let { "₹ $it" },
            e.detail.takeIf { it.isNotBlank() }, dateFmt.format(Date(e.date))).filterNotNull().joinToString("  •  ")
        card.addView(TextView(this).apply {
            text = details; textSize = 12f; setTextColor(muted); setPadding(0, dp(8), 0, 0)
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        val doneBtn = TextView(this).apply {
            text = if (e.done) (if (isEnglish()) "Reopen" else "फिर खोलें") else (if (isEnglish()) "Mark done" else "पूरा करें"); textSize = 12f; setTextColor(cyan)
            setPadding(dp(10), dp(9), dp(10), dp(4))
            setOnClickListener {
                val updated = load().map { if (it.id == e.id) it.copy(done = !it.done) else it }
                save(updated); render()
            }
        }
        val deleteBtn = TextView(this).apply {
            text = if (isEnglish()) "Delete" else "हटाएँ"; textSize = 12f; setTextColor(0xFFFF8C9A.toInt())
            setPadding(dp(10), dp(9), dp(2), dp(4))
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage(if (isEnglish()) "Delete this entry?" else "इस एंट्री को हटाएँ?")
                    .setNegativeButton(if (isEnglish()) "Cancel" else "रद्द", null).setPositiveButton(if (isEnglish()) "Delete" else "हटाएँ") { _, _ ->
                        save(load().filterNot { it.id == e.id }); render()
                    }.show()
            }
        }
        actions.addView(doneBtn); actions.addView(deleteBtn); card.addView(actions)
        parent.addView(card, match().apply { bottomMargin = dp(9) })
    }

    private fun showAddDialog(preselected: String?) {
        val types = if (isEnglish()) arrayOf("Bill / EMI", "Document", "Family task") else arrayOf("बिल / EMI", "दस्तावेज़", "परिवार का काम")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        val typeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, types)
            if (preselected != null) setSelection((if (isEnglish()) listOf("बिल / EMI", "दस्तावेज़", "परिवार का काम").indexOf(preselected) else types.indexOf(preselected)).coerceAtLeast(0))
        }
        val title = EditText(this).apply { hint = if (isEnglish()) "Name (e.g. Electricity bill)" else "नाम लिखें (जैसे बिजली बिल)"; setSingleLine(true) }
        val amount = EditText(this).apply { hint = if (isEnglish()) "Amount (optional)" else "रकम (वैकल्पिक)"; inputType = 2; setSingleLine(true) }
        val detail = EditText(this).apply { hint = if (isEnglish()) "Notes / assigned to (optional)" else "नोट / किसके लिए (वैकल्पिक)"; setSingleLine(true) }
        pendingPhotoUri = ""
        photoStatus = TextView(this).apply { text = if (isEnglish()) "No document photo selected" else "दस्तावेज़ की फोटो नहीं चुनी गई"; setTextColor(Color.DKGRAY); setPadding(0, dp(8), 0, dp(4)) }
        val photoBtn = Button(this).apply { text = if (isEnglish()) "Choose document photo" else "दस्तावेज़ की फोटो चुनें"; setOnClickListener {
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
            startActivityForResult(pick, PICK_PHOTO)
        } }
        var due = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val dateText = TextView(this).apply { text = "${if (isEnglish()) "Date" else "तारीख"}: ${dateFmt.format(Date(due))}"; setTextColor(Color.DKGRAY); setPadding(0, dp(10), 0, dp(4)) }
        val dateBtn = Button(this).apply {
            text = if (isEnglish()) "Choose date" else "तारीख चुनें"
            setOnClickListener {
                val c = Calendar.getInstance().apply { timeInMillis = due }
                DatePickerDialog(this@MainActivity, { _, y, m, d ->
                    c.set(y, m, d, 9, 0, 0); c.set(Calendar.MILLISECOND, 0)
                    due = c.timeInMillis; dateText.text = "${if (isEnglish()) "Date" else "तारीख"}: ${dateFmt.format(Date(due))}"
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
            }
        }
        box.addView(typeSpinner); box.addView(title); box.addView(amount); box.addView(detail); box.addView(photoBtn); box.addView(photoStatus); box.addView(dateText); box.addView(dateBtn)
        AlertDialog.Builder(this).setTitle(if (isEnglish()) "Add new entry" else "नई एंट्री जोड़ें").setView(box)
            .setNegativeButton(if (isEnglish()) "Cancel" else "रद्द", null)
            .setPositiveButton(if (isEnglish()) "Save" else "सेव करें") { _, _ ->
                val name = title.text.toString().trim()
                if (name.isBlank()) { Toast.makeText(this, if (isEnglish()) "Name is required" else "नाम लिखना जरूरी है", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val type = when (typeSpinner.selectedItem.toString()) { "Bill / EMI" -> "बिल / EMI"; "Document" -> "दस्तावेज़"; "Family task" -> "परिवार का काम"; else -> typeSpinner.selectedItem.toString() }
                val list = load()
                list.add(Entry(System.currentTimeMillis(), type, name, detail.text.toString().trim(),
                    amount.text.toString().trim(), due, false, if (type == "दस्तावेज़") pendingPhotoUri else ""))
                save(list); render()
                Toast.makeText(this, if (isEnglish()) "Saved" else "सेव हो गया", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun buildNav() {
        val items = if (isEnglish()) listOf("Home" to "⌂", "Bills" to "₹", "Docs" to "▣", "Family" to "✓", "Settings" to "☰") else listOf("होम" to "⌂", "बिल" to "₹", "दस्तावेज़" to "▣", "परिवार" to "✓", "प्रोफाइल" to "☰")
        items.forEach { (name, icon) ->
            val tabKey = if (isEnglish()) mapOf("Home" to "होम", "Bills" to "बिल", "Docs" to "दस्तावेज़", "Family" to "परिवार", "Settings" to "प्रोफाइल")[name] else name
            val active = selectedTab == name || selectedTab == tabKey
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(dp(3), dp(5), dp(3), dp(3))
                setOnClickListener { selectedTab = tabKey ?: name; render() }
            }
            col.addView(TextView(this).apply {
                text = icon; textSize = 21f; gravity = Gravity.CENTER
                setTextColor(if (active) cyan else muted)
            })
            col.addView(TextView(this).apply {
                text = name; textSize = 10f; gravity = Gravity.CENTER
                setTextColor(if (active) cyan else muted)
            })
            nav.addView(col, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun statCard(title: String, count: String, sub: String, accent: Int, icon: String, action: () -> Unit): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(14), dp(12))
            background = rounded(panel, 18); setOnClickListener { action() }
        }
        c.addView(TextView(this).apply { text = icon; textSize = 20f; setTextColor(accent) })
        c.addView(TextView(this).apply { text = count; textSize = 25f; setTypeface(null, Typeface.BOLD); setTextColor(white); setPadding(0, dp(3), 0, 0) })
        c.addView(TextView(this).apply { text = title; textSize = 13f; setTextColor(white) })
        c.addView(TextView(this).apply { text = sub; textSize = 10f; setTextColor(muted); setPadding(0, dp(3), 0, 0) })
        return c
    }

    private fun infoCard(title: String, desc: String) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = rounded(panel, 18) }
        c.addView(TextView(this).apply { text = title; textSize = 16f; setTextColor(white); setTypeface(null, Typeface.BOLD) })
        c.addView(TextView(this).apply { text = desc; textSize = 13f; setTextColor(muted); setPadding(0, dp(7), 0, 0) })
        body.addView(c, match().apply { bottomMargin = dp(10) })
    }

    private fun emptyState(title: String, desc: String) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(26), dp(20), dp(26)); background = rounded(panel, 18) }
        c.addView(TextView(this).apply { text = "✦"; textSize = 28f; setTextColor(purple); gravity = Gravity.CENTER })
        c.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(white); gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD) })
        c.addView(TextView(this).apply { text = desc; textSize = 12f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
        body.addView(c, match())
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) {
        body.addView(TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        })
    }

    private fun chip(label: String, action: () -> Unit): View {
        val t = TextView(this).apply {
            text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(white)
            background = rounded(0x334FFFFF, 30); setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { action() }
        }
        return t
    }

    private fun button(label: String, color: Int, action: () -> Unit) {
        val b = Button(this).apply { text = label; isAllCaps = false; setTextColor(bg); setBackground(rounded(color, 14)); setOnClickListener { action() } }
        body.addView(b, match())
    }

    private fun openAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
                return
            }
        }
        Toast.makeText(this, "रिमाइंडर शेड्यूल करने की अनुमति उपलब्ध है", Toast.LENGTH_LONG).show()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun match() = LinearLayout.LayoutParams(-1, -2)
    private fun space(v: Int) { body.addView(View(this), LinearLayout.LayoutParams(1, dp(v))) }
    private fun spaceIn(parent: LinearLayout, v: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(v))) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
