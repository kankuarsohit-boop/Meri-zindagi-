package com.merizindagi.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Entry(
    val id: Long,
    val type: String,
    val title: String,
    val detail: String,
    val amount: String,
    val date: Long,
    val done: Boolean,
    val photoUri: String = "",
    val category: String = "",
    val expiryDate: Long = 0L
)

class MainActivity : androidx.fragment.app.FragmentActivity() {
    // Keep each signed-in Firebase account in a separate local preference file.
    // The original pre-login data file is retained as the guest/legacy store.
    private var loggedOut = false
    private val prefs: android.content.SharedPreferences
        get() = getSharedPreferences(auth.currentUser?.uid?.let { "merizindagi_data_$it" } ?: if (loggedOut) "merizindagi_data_signed_out" else "merizindagi_data", MODE_PRIVATE)

    private fun migrateGuestDataToCurrentAccount() {
        val user = auth.currentUser ?: return
        val guest = getSharedPreferences("merizindagi_data", MODE_PRIVATE)
        val account = getSharedPreferences("merizindagi_data_${user.uid}", MODE_PRIVATE)
        // Only migrate legacy phone data into a newly used account; never overwrite existing account data.
        if (account.getString("entries", null) == null && guest.getString("entries", null) != null) {
            val editor = account.edit()
            guest.all.forEach { (key, value) ->
                when (value) {
                    is String -> editor.putString(key, value)
                    is Boolean -> editor.putBoolean(key, value)
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is Float -> editor.putFloat(key, value)
                    is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toSet())
                }
            }
            editor.apply()
        }
    }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val cloud by lazy { FirebaseFirestore.getInstance() }
    private var cloudReady = false
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var nav: LinearLayout
    private var selectedTab = "होम"
    private var selectedDocumentCategory = ""
    private var bg = Color.rgb(9, 15, 31)
    private var panel = Color.rgb(19, 29, 51)
    private var panel2 = Color.rgb(25, 38, 65)
    private var white = Color.rgb(241, 246, 255)
    private var muted = Color.rgb(153, 169, 198)
    private val cyan = Color.rgb(198, 164, 92)
    private val purple = Color.rgb(155, 125, 255)
    private val orange = Color.rgb(255, 183, 91)
    private var pendingPhotoUri = ""
    private var photoStatus: TextView? = null
    private var photoPreview: ImageView? = null
    private val PICK_PHOTO = 501
    private val TAKE_DOCUMENT_PHOTO = 506
    private var cameraOutputUri: Uri? = null
    private val BACKUP_CREATE = 502
    private val BACKUP_OPEN = 503
    private val PDF_CREATE = 504
    private val CSV_CREATE = 505
    private val dateFmt get() = SimpleDateFormat("dd MMM yyyy", if (prefs.getString("language", "hi") == "en") Locale.ENGLISH else Locale("hi", "IN"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyTheme()
        ReminderScheduler.createChannel(this)
        askNotificationPermission()
        ReminderScheduler.schedule(this)
        render()
        if (auth.currentUser == null) showAuthDialog() else syncFromCloud()
        if (prefs.getString("app_pin", "").orEmpty().isNotBlank()) showPinDialog()
        else if (prefs.getBoolean("biometric_enabled", false) && auth.currentUser != null) showBiometricLaunchGate()
    }

    private fun applyTheme() {
        val light = prefs.getBoolean("light_theme", false)
        bg = if (light) Color.rgb(244, 246, 250) else Color.rgb(9, 15, 31)
        panel = if (light) Color.WHITE else Color.rgb(19, 29, 51)
        panel2 = if (light) Color.rgb(231, 236, 244) else Color.rgb(25, 38, 65)
        white = if (light) Color.rgb(24, 32, 48) else Color.rgb(241, 246, 255)
        muted = if (light) Color.rgb(94, 108, 130) else Color.rgb(153, 169, 198)
        window.statusBarColor = bg; window.navigationBarColor = bg; window.decorView.systemUiVisibility = if (light) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun load(): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val a = JSONArray(prefs.getString("entries", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Entry(o.optLong("id"), o.optString("type"), o.optString("title"),
                    o.optString("detail"), o.optString("amount"), o.optLong("date"), o.optBoolean("done"), o.optString("photoUri"), o.optString("category"), o.optLong("expiryDate", 0L)))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun save(list: List<Entry>) {
        val a = JSONArray()
        list.forEach { e ->
            a.put(JSONObject().put("id", e.id).put("type", e.type).put("title", e.title)
                .put("detail", e.detail).put("amount", e.amount).put("date", e.date).put("done", e.done).put("photoUri", e.photoUri).put("category", e.category).put("expiryDate", e.expiryDate))
        }
        prefs.edit().putString("entries", a.toString()).apply()
        if (cloudReady) {
            val user = auth.currentUser
            if (user != null) cloud.collection("users").document(user.uid).collection("appData").document("main")
                .set(mapOf(
                    "entries" to a.toString(),
                    "language" to prefs.getString("language", "hi"),
                    "lightTheme" to prefs.getBoolean("light_theme", false),
                    "updatedAt" to System.currentTimeMillis()
                ))
                .addOnFailureListener { toast(if (isEnglish()) "Cloud sync failed. Local data is safe." else "क्लाउड सिंक नहीं हुआ। फोन का डेटा सुरक्षित है।") }
        }
    }

    private fun showAuthDialog() {
        val email = EditText(this).apply { hint = "Email"; inputType = 33; setSingleLine(true) }
        val password = EditText(this).apply { hint = if (isEnglish()) "Password (minimum 6 characters)" else "पासवर्ड (कम से कम 6 अक्षर)"; inputType = 129; setSingleLine(true) }
        val username = EditText(this).apply { hint = if (isEnglish()) "Display name (for new account)" else "नाम (नया अकाउंट बनाने के लिए)"; setSingleLine(true) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0); addView(username); addView(email); addView(password) }
        val dialog = AlertDialog.Builder(this).setTitle(if (isEnglish()) "MeriZindagi account" else "MeriZindagi अकाउंट")
            .setMessage(if (isEnglish()) "Sign in or create an account with email and password. Display name is saved on new accounts. Existing phone data is kept." else "ईमेल और पासवर्ड से लॉगिन या नया अकाउंट बनाएँ। नया अकाउंट बनाते समय नाम सेव होगा। फोन का पुराना डेटा सुरक्षित रहेगा।")
            .setView(box).setPositiveButton(if (isEnglish()) "Login" else "लॉगिन", null)
            .setNeutralButton(if (isEnglish()) "Create account" else "अकाउंट बनाएँ", null)
            .setNegativeButton(if (isEnglish()) "Forgot password" else "पासवर्ड भूल गए?", null).setCancelable(false).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val em=email.text.toString().trim(); val pw=password.text.toString()
                if (em.isBlank() || pw.length < 6) { toast(if (isEnglish()) "Enter valid email and 6+ character password" else "सही ईमेल और कम से कम 6 अक्षर का पासवर्ड लिखें"); return@setOnClickListener }
                auth.signInWithEmailAndPassword(em,pw).addOnSuccessListener { loggedOut=false; migrateGuestDataToCurrentAccount(); dialog.dismiss(); syncFromCloud() }
                    .addOnFailureListener { toast(it.localizedMessage ?: "Login failed") }
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val em=email.text.toString().trim(); val pw=password.text.toString(); val name=username.text.toString().trim()
                if (em.isBlank() || pw.length < 6) { toast(if (isEnglish()) "Enter valid email and 6+ character password" else "सही ईमेल और कम से कम 6 अक्षर का पासवर्ड लिखें"); return@setOnClickListener }
                auth.createUserWithEmailAndPassword(em,pw).addOnSuccessListener { result ->
                    val user=result.user
                    if (user != null) {
                        val profile= com.google.firebase.auth.UserProfileChangeRequest.Builder().setDisplayName(name).build()
                        user.updateProfile(profile).addOnCompleteListener { loggedOut=false; migrateGuestDataToCurrentAccount(); dialog.dismiss(); syncFromCloud() }
                    } else { loggedOut=false; migrateGuestDataToCurrentAccount(); dialog.dismiss(); syncFromCloud() }
                }.addOnFailureListener { toast(it.localizedMessage ?: "Account creation failed") }
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                val em=email.text.toString().trim()
                if (em.isBlank()) { toast(if (isEnglish()) "Enter your email first" else "पहले अपना ईमेल लिखें"); return@setOnClickListener }
                auth.sendPasswordResetEmail(em).addOnSuccessListener { toast(if (isEnglish()) "Password reset email sent" else "पासवर्ड रीसेट ईमेल भेज दिया गया") }
                    .addOnFailureListener { toast(it.localizedMessage ?: "Could not send reset email") }
            }
        }
        dialog.show()
    }

    private fun syncFromCloud() {
        val user=auth.currentUser ?: run { cloudReady=false; showAuthDialog(); return }
        cloud.collection("users").document(user.uid).collection("appData").document("main").get()
            .addOnSuccessListener { snap ->
                val remote=snap.getString("entries")
                if (!remote.isNullOrBlank()) {
                    // Merge by entry ID so first login never discards data already on this phone.
                    val merged=LinkedHashMap<Long, JSONObject>()
                    try { val local=JSONArray(prefs.getString("entries","[]") ?: "[]"); for(i in 0 until local.length()){ val o=local.getJSONObject(i); merged[o.optLong("id")]=o } } catch (_:Exception) {}
                    try { val arr=JSONArray(remote); for(i in 0 until arr.length()){ val o=arr.getJSONObject(i); merged[o.optLong("id")]=o } } catch (_:Exception) {}
                    val result=JSONArray(); merged.values.forEach { result.put(it) }; prefs.edit().putString("entries",result.toString()).apply()
                }
                if (snap.contains("language")) {
                    prefs.edit().putString("language", snap.getString("language") ?: "hi").apply()
                }
                if (snap.contains("lightTheme")) {
                    prefs.edit().putBoolean("light_theme", snap.getBoolean("lightTheme") ?: false).apply()
                }
                cloudReady=true
                // Upload local data if cloud was empty, or the merged result after first sign-in.
                val local=prefs.getString("entries","[]") ?: "[]"
                cloud.collection("users").document(user.uid).collection("appData").document("main")
                    .set(mapOf(
                        "entries" to local,
                        "language" to prefs.getString("language", "hi"),
                        "lightTheme" to prefs.getBoolean("light_theme", false),
                        "updatedAt" to System.currentTimeMillis()
                    ))
                    .addOnSuccessListener { render(); toast(if (isEnglish()) "Cloud sync ready" else "क्लाउड सिंक जुड़ गया") }
                    .addOnFailureListener { render(); toast(if (isEnglish()) "Cloud sync unavailable; phone data is safe" else "क्लाउड सिंक उपलब्ध नहीं; फोन का डेटा सुरक्षित है") }
            }
            .addOnFailureListener { cloudReady=false; render(); toast(it.localizedMessage ?: "Cloud sync failed") }
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        root.addView(topHeader(), LinearLayout.LayoutParams(-1, dp(82)).apply {
            setMargins(dp(12), dp(12), dp(12), dp(5))
        })
        val scroll = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(26))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = rounded(Color.rgb(15, 24, 43), 24)
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(70)).apply {
            setMargins(dp(12), dp(5), dp(12), dp(12))
        })
        setContentView(root)
        when (selectedTab) {
            "होम" -> home()
            "बिल" -> listing("बिल / EMI")
            "दस्तावेज़" -> listing("दस्तावेज़")
            "परिवार" -> listing("परिवार का काम")
            "प्रोफाइल" -> profile()
        }
        buildNav()
    }


    private fun topHeader(): View {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(15), dp(11), dp(13), dp(11))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(26, 43, 72), Color.rgb(10, 17, 32), Color.rgb(20, 27, 47))).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.rgb(72, 91, 125))
            }
        }
        val mark = TextView(this).apply {
            text = "✧"; textSize = 28f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(235, 198, 119))
            background = rounded(Color.rgb(34, 49, 76), 16)
        }
        header.addView(mark, LinearLayout.LayoutParams(dp(44), dp(44)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), 0, 0, 0) }
        titles.addView(TextView(this).apply {
            text = "MeriZindagi"; textSize = 22f; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(224, 190, 112))
        })
        titles.addView(TextView(this).apply {
            text = if (isEnglish()) "SMART LIFE • SECURE • ORGANIZED" else "स्मार्ट लाइफ  •  सुरक्षित  •  व्यवस्थित"
            textSize = 10f; setTextColor(Color.rgb(151, 176, 210))
        })
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        val menuBtn = TextView(this).apply {
            text = "⋮"; textSize = 26f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(224, 190, 112)); background = rounded(Color.rgb(30, 43, 65), 13)
            setOnClickListener { showTopMenu(this) }
        }
        header.addView(menuBtn, LinearLayout.LayoutParams(dp(42), dp(44)))
        return header
    }

    private fun showTopMenu(anchor: View) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(if (isEnglish()) "Settings" else "सेटिंग्स").setOnMenuItemClickListener {
            selectedTab = "प्रोफाइल"; render(); true
        }
        menu.menu.add(if (isEnglish()) "Enable fingerprint" else "फिंगरप्रिंट चालू करें").setOnMenuItemClickListener {
            enableBiometric(); true
        }
        menu.menu.add(if (isEnglish()) "Set / change PIN" else "PIN सेट / बदलें").setOnMenuItemClickListener {
            setPin(); true
        }
        menu.menu.add(if (isEnglish()) "Toggle theme" else "थीम बदलें").setOnMenuItemClickListener {
            prefs.edit().putBoolean("light_theme", !prefs.getBoolean("light_theme", false)).apply()
            syncPreferencesToCloud(); applyTheme(); render(); true
        }
        menu.menu.add(if (isEnglish()) "Create backup" else "बैकअप बनाएँ").setOnMenuItemClickListener {
            createBackup(); true
        }
        menu.menu.add(if (isEnglish()) "Sync now" else "अभी सिंक करें").setOnMenuItemClickListener {
            if (auth.currentUser != null) { cloudReady = true; syncFromCloud() }
            else toast(if (isEnglish()) "Sign in first" else "पहले लॉगिन करें")
            true
        }
        menu.show()
    }

    private fun home() {
        val list = load()
        val bills = list.filter { it.type == "बिल / EMI" }
        val docs = list.filter { it.type == "दस्तावेज़" }
        val tasks = list.filter { it.type == "परिवार का काम" }
        val pending = list.count { !it.done }
        text(if (isEnglish()) "Your life, beautifully organized" else "आपकी ज़िंदगी, अब और व्यवस्थित", 14f, muted, false)
        space(14)
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(25, 65, 103), Color.rgb(39, 48, 99), Color.rgb(64, 43, 107))).apply { cornerRadius = dp(27).toFloat(); setStroke(dp(1), Color.rgb(84, 108, 159)) }
        }
        hero.addView(TextView(this).apply { text = if (isEnglish()) "TODAY'S OVERVIEW" else "आज का ओवरव्यू"; textSize = 14f; setTextColor(0xFFDDE7FF.toInt()) })
        hero.addView(TextView(this).apply {
            text = "$pending"; textSize = 42f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE)
            setPadding(0, dp(4), 0, 0)
        })
        hero.addView(TextView(this).apply { text = if (isEnglish()) "Pending tasks and reminders" else "पेंडिंग काम और रिमाइंडर"; textSize = 14f; setTextColor(0xFFDDE7FF.toInt()) })
        spaceIn(hero, 14)
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        quick.addView(chip(if (isEnglish()) "＋ Add new" else "＋ नया जोड़ें") { showAddDialog(null) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        quick.addView(chip(if (isEnglish()) "⏰ Reminders" else "⏰ रिमाइंडर") { openAlarmSettings() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(8) })
        hero.addView(quick)
        body.addView(hero, match().apply { bottomMargin = dp(18) })

        text(if (isEnglish()) "Your manager" else "आपका मैनेजर", 20f, white, true)
        text(if (isEnglish()) "Everything important in one place" else "ज़रूरी चीज़ें एक ही जगह", 13f, muted, false)
        space(10)
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(statCard(if (isEnglish()) "Bills / EMI" else "बिल / EMI", bills.size.toString(), if (isEnglish()) "Track payments" else "भुगतान ट्रैक करें", cyan, "₹") { selectedTab = "बिल"; render() },
            LinearLayout.LayoutParams(0, dp(128), 1f))
        row1.addView(statCard(if (isEnglish()) "Documents" else "दस्तावेज़", docs.size.toString(), if (isEnglish()) "Track expiry dates" else "एक्सपायरी याद रखें", purple, "▣") { selectedTab = "दस्तावेज़"; render() },
            LinearLayout.LayoutParams(0, dp(128), 1f).apply { leftMargin = dp(10) })
        body.addView(row1)
        space(10)
        body.addView(statCard(if (isEnglish()) "Family tasks" else "परिवार के काम", tasks.size.toString(), if (isEnglish()) "Assign and complete tasks" else "काम बाँटें और पूरा करें", orange, "✓") {
            selectedTab = "परिवार"; render()
        }, match().apply { height = dp(112) })

        space(20)
        text(if (isEnglish()) "Upcoming reminders" else "आने वाले रिमाइंडर", 20f, white, true)
        text(if (isEnglish()) "Your list by date" else "तारीख के अनुसार आपकी सूची", 13f, muted, false)
        space(8)
        val upcoming = list.filter { !it.done }.sortedBy { it.date }.take(4)
        if (upcoming.isEmpty()) emptyState(if (isEnglish()) "No pending reminders" else "अभी कोई पेंडिंग रिमाइंडर नहीं", if (isEnglish()) "Use + to add a bill, document or task" else "＋ बटन से बिल, दस्तावेज़ या काम जोड़ें")
        else upcoming.forEach { entryCard(it, compact = true) }
        space(12)
        text(if (isEnglish()) "Quick add" else "त्वरित जोड़ें", 18f, white, true)
        val addRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("बिल / EMI", "दस्तावेज़", "परिवार का काम").forEach { type ->
            addRow.addView(chip("+ ${type.replace("परिवार का काम", "काम")}") { showAddDialog(type) },
                LinearLayout.LayoutParams(0, dp(46), 1f).apply { if (type != "बिल / EMI") leftMargin = dp(5) })
        }
        body.addView(addRow)
    }

    private fun listing(type: String) {
        val heading = if (type == "बिल / EMI") (if (isEnglish()) "Bills & EMIs" else "बिल और EMI") else if (type == "दस्तावेज़") (if (isEnglish()) "My documents" else "मेरे दस्तावेज़") else (if (isEnglish()) "Family tasks" else "परिवार के काम")
        text(heading, 27f, white, true)
        text(when (type) {
            "बिल / EMI" -> if (isEnglish()) "Track payments and installments" else "भुगतान और किस्तों पर नज़र रखें"
            "दस्तावेज़" -> if (isEnglish()) "Important documents and expiry dates" else "जरूरी दस्तावेज़ और उनकी तारीखें"
            else -> if (isEnglish()) "Organize family tasks" else "परिवार के काम व्यवस्थित करें"
        }, 14f, muted, false)
        space(14)
        if (type == "दस्तावेज़") {
            val docs = load().filter { it.type == "दस्तावेज़" }
            val categories = if (isEnglish()) listOf("Identity proof", "Bank", "Insurance", "Vehicle", "Education", "Property", "Other") else listOf("पहचान पत्र", "बैंक", "बीमा", "वाहन", "शिक्षा", "संपत्ति", "अन्य")
            button(if (isEnglish()) "Show all documents (${docs.size})" else "सभी दस्तावेज़ दिखाएँ (${docs.size})", purple) { selectedDocumentCategory = ""; render() }
            categories.chunked(3).forEach { group ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                group.forEachIndexed { index, category ->
                    val count = docs.count { it.category.equals(category, true) }
                    val categoryCard = statCard(category, count.toString(), if (isEnglish()) "Saved files" else "सेव फाइलें", if (selectedDocumentCategory == category) orange else cyan, "▣") { selectedDocumentCategory = category; render() }
                    row.addView(categoryCard, LinearLayout.LayoutParams(0, dp(94), 1f).apply { if (index > 0) leftMargin = dp(7) })
                }
                while (row.childCount < 3) row.addView(View(this), LinearLayout.LayoutParams(0, dp(94), 1f).apply { leftMargin = dp(7) })
                body.addView(row); space(8)
            }
        }
        button(if (isEnglish()) "＋ Add ${if (type == "परिवार का काम") "task" else if (type == "दस्तावेज़") "document" else "bill / EMI"}" else "＋ नया ${if (type == "परिवार का काम") "काम" else if (type == "दस्तावेज़") "दस्तावेज़" else "बिल / EMI"} जोड़ें", cyan) {
            showAddDialog(type)
        }
        space(12)
        val search = EditText(this).apply { hint = if (isEnglish()) "Search entries..." else "एंट्री खोजें..."; setSingleLine(true) }
        body.addView(search, match().apply { bottomMargin = dp(8) })
        val allEntries = load().filter { it.type == type }.sortedBy { it.date }
        val entries = allEntries
        if (entries.isEmpty()) emptyState(if (isEnglish()) "Nothing added yet" else "अभी कुछ जोड़ा नहीं गया", if (isEnglish()) "Use the button above to add your first entry" else "ऊपर के बटन से पहली एंट्री जोड़ें")
        else {
            val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            body.addView(holder)
            fun showMatches(q: String) {
                holder.removeAllViews()
                val found = entries.filter { (selectedDocumentCategory.isBlank() || it.category.equals(selectedDocumentCategory, true)) && (it.title.contains(q, true) || it.detail.contains(q, true)) }
                if (found.isEmpty()) holder.addView(TextView(this).apply { text = if (isEnglish()) "No matching entries" else "कोई एंट्री नहीं मिली"; setTextColor(muted) })
                else found.forEach { entryCardInto(holder, it) }
            }
            showMatches("")
            search.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { showMatches(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
    }

    private fun profile() {
        text(if (isEnglish()) "Settings" else "सेटिंग्स", 27f, white, true)
        text("MeriZindagi • Premium Life Manager", 14f, muted, false)
        space(18)
        infoCard("🌐  " + if (isEnglish()) "Language" else "भाषा", if (isEnglish()) "Current: English" else "वर्तमान: हिंदी")
        button(if (isEnglish()) "Change language" else "भाषा बदलें", cyan) { chooseLanguage() }
        space(8)
        infoCard("🎨  " + if (isEnglish()) "Appearance" else "दिखावट", if (prefs.getBoolean("light_theme", false)) (if (isEnglish()) "Light mode is on" else "लाइट मोड चालू है") else (if (isEnglish()) "Dark mode is on" else "डार्क मोड चालू है"))
        button(if (isEnglish()) "Toggle light / dark mode" else "लाइट / डार्क मोड बदलें", purple) {
            prefs.edit().putBoolean("light_theme", !prefs.getBoolean("light_theme", false)).apply()
            syncPreferencesToCloud(); applyTheme(); render()
        }
        space(8)
        infoCard("⏰  " + if (isEnglish()) "9 AM smart reminders" else "सुबह 9 बजे स्मार्ट रिमाइंडर", if (isEnglish()) "Alerts for bills, EMIs and document dates" else "बिल, EMI और दस्तावेज़ की तारीख से पहले अलर्ट")
        button(if (isEnglish()) "Notification / alarm settings" else "नोटिफिकेशन / अलार्म सेटिंग खोलें", orange) { openAlarmSettings() }
        space(8)
        val pinOn = prefs.getString("app_pin", "").orEmpty().isNotBlank()
        val biometricOn = prefs.getBoolean("biometric_enabled", false)
        infoCard("🔐  " + if (isEnglish()) "App lock & security" else "ऐप लॉक और सुरक्षा", (if (isEnglish()) "App lock: " else "ऐप लॉक: ") + (if (pinOn) (if (isEnglish()) "ON (PIN)" else "चालू (PIN)") else (if (isEnglish()) "OFF" else "बंद")) + "  •  " + (if (isEnglish()) "Biometric: " else "बायोमेट्रिक: ") + (if (biometricOn) (if (isEnglish()) "ON" else "चालू") else (if (isEnglish()) "OFF" else "बंद")))
        button(if (isEnglish()) "Set / change PIN" else "PIN सेट / बदलें", purple) { setPin() }
        button(if (isEnglish()) "Enable fingerprint / face" else "फिंगरप्रिंट / फेस चालू करें", cyan) { enableBiometric() }
        button(if (isEnglish()) "Turn biometric OFF" else "बायोमेट्रिक बंद करें", orange) {
            if (!biometricOn) toast(if (isEnglish()) "Biometric is already OFF" else "बायोमेट्रिक पहले से बंद है")
            else showBiometricPrompt(onSuccess = { prefs.edit().putBoolean("biometric_enabled", false).apply(); render(); toast(if (isEnglish()) "Biometric disabled" else "बायोमेट्रिक बंद हो गया") })
        }
        button(if (isEnglish()) "Turn app PIN lock OFF" else "ऐप PIN लॉक बंद करें", orange) {
            if (!pinOn) toast(if (isEnglish()) "PIN lock is already OFF" else "PIN लॉक पहले से बंद है")
            else showBiometricOrPinConfirm { prefs.edit().remove("app_pin").apply(); render(); toast(if (isEnglish()) "PIN lock removed" else "PIN लॉक हटा दिया गया") }
        }
        space(8)
        infoCard("📄  " + if (isEnglish()) "Export report" else "रिपोर्ट एक्सपोर्ट", if (isEnglish()) "Create a PDF summary of your entries" else "अपनी एंट्री की PDF रिपोर्ट बनाएँ")
        button(if (isEnglish()) "Export PDF" else "PDF रिपोर्ट बनाएँ", cyan) { createPdf() }
        button(if (isEnglish()) "Export CSV (Excel compatible)" else "CSV / Excel रिपोर्ट एक्सपोर्ट करें", purple) { createCsv() }
        space(8)
        infoCard("👨‍👩‍👧  " + if (isEnglish()) "Family accounts" else "परिवार के अलग अकाउंट", if (isEnglish()) "Each family member can sign in with their own Firebase email account on this device. Shared family workspace and role permissions need a separate secure setup." else "परिवार का हर सदस्य इस फोन पर अपने Firebase ईमेल अकाउंट से लॉगिन कर सकता है। साझा फैमिली वर्कस्पेस और अलग-अलग अनुमति के लिए अलग सुरक्षित सेटअप जरूरी है।")
        space(8)
        infoCard("☁️  " + if (isEnglish()) "Backup & restore" else "बैकअप और रिस्टोर", if (isEnglish()) "Save your data as a file or restore it later" else "अपना डेटा फाइल में सेव करें या बाद में वापस लाएँ")
        button(if (isEnglish()) "Create backup" else "बैकअप बनाएँ", cyan) { createBackup() }
        button(if (isEnglish()) "Restore backup" else "बैकअप वापस लाएँ", purple) { restoreBackup() }
        space(8)
        val signedIn = auth.currentUser
        infoCard("☁️  " + if (isEnglish()) "Cloud account" else "क्लाउड अकाउंट", signedIn?.email ?: (if (isEnglish()) "Not signed in" else "लॉगिन नहीं है"))
        if (signedIn != null) button(if (isEnglish()) "Sync now" else "अभी सिंक करें", cyan) { cloudReady = true; syncFromCloud() }
        if (signedIn != null) button(if (isEnglish()) "Add / switch account" else "दूसरा अकाउंट जोड़ें / बदलें", purple) {
            AlertDialog.Builder(this)
                .setTitle(if (isEnglish()) "Add or switch account" else "अकाउंट जोड़ें या बदलें")
                .setMessage(if (isEnglish()) "Your current account data is saved separately on this phone. Sign out, then log in or create another account. The other account's data will remain separate." else "आपके मौजूदा अकाउंट का डेटा इस फोन में अलग सेव है। लॉगआउट करके दूसरे अकाउंट से लॉगिन करें या नया अकाउंट बनाएँ। दूसरे अकाउंट का डेटा अलग रहेगा।")
                .setNegativeButton(if (isEnglish()) "Cancel" else "रद्द करें", null)
                .setPositiveButton(if (isEnglish()) "Continue" else "आगे बढ़ें") { _, _ -> cloudReady=false; auth.signOut(); showAuthDialog() }
                .show()
        }
        if (signedIn != null) button(if (isEnglish()) "Log out" else "लॉगआउट", orange) {
            AlertDialog.Builder(this)
                .setTitle(if (isEnglish()) "Log out?" else "लॉगआउट करें?")
                .setMessage(if (isEnglish()) "Your account's local data will be kept on this phone." else "इस अकाउंट का लोकल डेटा इस फोन में सुरक्षित रहेगा।")
                .setNegativeButton(if (isEnglish()) "Cancel" else "रद्द करें", null)
                .setPositiveButton(if (isEnglish()) "Log out" else "लॉगआउट") { _, _ -> cloudReady=false; auth.signOut(); loggedOut=true; render(); showAuthDialog() }
                .show()
        }
        infoCard("⭐  Premium", if (isEnglish()) "Premium plan preview. Online photo storage and paid subscriptions are not activated yet." else "Premium प्लान का प्रीव्यू। फोटो क्लाउड स्टोरेज और भुगतान वाली सदस्यता अभी चालू नहीं है।")
        infoCard(if (isEnglish()) "Your privacy" else "आपकी जानकारी", if (isEnglish()) "Entries and language/theme settings sync to your signed-in Firebase account. App PIN and photo files remain on this phone; keep a backup." else "एंट्री और भाषा/थीम की सेटिंग लॉगिन Firebase अकाउंट से सिंक होती हैं। ऐप PIN और फोटो फाइल इसी फोन में रहती हैं; बैकअप रखें।")
        infoCard("Version 3.3", "Separate personal accounts • Add / switch account • Logout • Offline-first • Firebase sync • PDF + CSV export")
    }

    private fun syncPreferencesToCloud() {
        val user = auth.currentUser ?: return
        if (!cloudReady) return
        cloud.collection("users").document(user.uid).collection("appData").document("main")
            .set(mapOf(
                "entries" to (prefs.getString("entries", "[]") ?: "[]"),
                "language" to prefs.getString("language", "hi"),
                "lightTheme" to prefs.getBoolean("light_theme", false),
                "updatedAt" to System.currentTimeMillis()
            ))
            .addOnFailureListener {
                toast(if (isEnglish()) "Settings sync failed; phone settings are safe." else "सेटिंग्स सिंक नहीं हुईं; फोन की सेटिंग सुरक्षित हैं।")
            }
    }

    private fun isEnglish() = prefs.getString("language", "hi") == "en"
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun chooseLanguage() {
        AlertDialog.Builder(this).setTitle("Language / भाषा")
            .setSingleChoiceItems(arrayOf("हिंदी", "English"), if (isEnglish()) 1 else 0) { d, which ->
                prefs.edit().putString("language", if (which == 1) "en" else "hi").apply()
                syncPreferencesToCloud(); d.dismiss(); render()
            }.setNegativeButton(if (isEnglish()) "Cancel" else "रद्द", null).show()
    }

    private fun showBiometricOrPinConfirm(onSuccess: () -> Unit) {
        val pin = prefs.getString("app_pin", "").orEmpty()
        val biometricsAvailable = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
        if (prefs.getBoolean("biometric_enabled", false) && biometricsAvailable) {
            showBiometricPrompt(onSuccess = onSuccess)
        } else if (pin.isNotBlank()) {
            val field = EditText(this).apply { hint = if (isEnglish()) "Enter current PIN" else "वर्तमान PIN लिखें"; inputType = 2; setSingleLine(true) }
            AlertDialog.Builder(this).setTitle(if (isEnglish()) "Confirm security" else "सुरक्षा की पुष्टि")
                .setView(field).setNegativeButton(if (isEnglish()) "Cancel" else "रद्द", null)
                .setPositiveButton(if (isEnglish()) "Verify" else "जाँचें") { _, _ ->
                    if (field.text.toString() == pin) onSuccess() else toast(if (isEnglish()) "Incorrect PIN" else "गलत PIN")
                }.show()
        } else onSuccess()
    }


    private fun setPin() {
        val field = EditText(this).apply { hint = if (isEnglish()) "Enter 4 digit PIN" else "4 अंकों का PIN लिखें"; inputType = 2; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle(if (isEnglish()) "Set app PIN" else "ऐप PIN सेट करें").setView(field)
            .setNegativeButton(if (isEnglish()) "Cancel" else "रद्द", null)
            .setPositiveButton(if (isEnglish()) "Save" else "सेव") { _, _ ->
                val pin = field.text.toString().trim()
                if (pin.matches(Regex("\\d{4}"))) { prefs.edit().putString("app_pin", pin).apply(); toast(if (isEnglish()) "PIN saved" else "PIN सेव हो गया") }
                else toast(if (isEnglish()) "Enter exactly 4 digits" else "4 अंक का PIN लिखें")
            }.show()
    }

    private fun showPinDialog() {
        val field = EditText(this).apply { hint = "PIN"; inputType = 2; setSingleLine(true) }
        val hasBio = prefs.getBoolean("biometric_enabled", false) && BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
        val builder = AlertDialog.Builder(this).setTitle(if (isEnglish()) "Unlock MeriZindagi" else "MeriZindagi अनलॉक करें")
            .setMessage(if (isEnglish()) "Enter your 4-digit PIN" else "अपना 4 अंकों का PIN लिखें")
            .setView(field).setCancelable(false).setPositiveButton(if (isEnglish()) "Unlock" else "खोलें", null)
        if (hasBio) builder.setNeutralButton(if (isEnglish()) "Use fingerprint" else "फिंगरप्रिंट से खोलें", null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(-1).setOnClickListener {
                if (field.text.toString() == prefs.getString("app_pin", "")) dialog.dismiss()
                else { field.error = if (isEnglish()) "Incorrect PIN" else "गलत PIN" }
            }
            if (hasBio) dialog.getButton(-3).setOnClickListener { showBiometricPrompt(onSuccess = { dialog.dismiss() }) }
        }
        dialog.show()
    }

    private fun showBiometricLaunchGate() {
        showBiometricPrompt(onSuccess = {}, onTerminalError = { finish() })
    }

    private fun showBiometricPrompt(onSuccess: () -> Unit, onTerminalError: (() -> Unit)? = null) {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            toast(if (isEnglish()) "Biometric unavailable. Use PIN or set up biometrics in phone settings." else "बायोमेट्रिक उपलब्ध नहीं। PIN इस्तेमाल करें या फोन सेटिंग में सेट करें।")
            onTerminalError?.invoke()
            return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onSuccess() }
            override fun onAuthenticationFailed() { toast(if (isEnglish()) "Fingerprint not recognized" else "फिंगरप्रिंट पहचान नहीं हुआ") }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { toast(errString.toString()); onTerminalError?.invoke() }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(if (isEnglish()) "Unlock MeriZindagi" else "MeriZindagi अनलॉक करें")
            .setSubtitle(if (isEnglish()) "Verify using your device biometric" else "फोन के फिंगरप्रिंट से पुष्टि करें")
            .setAllowedAuthenticators(authenticators)
            .setNegativeButtonText(if (isEnglish()) "Cancel" else "रद्द")
            .build()
        prompt.authenticate(info)
    }

    private fun createBackup() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "MeriZindagi-Backup.json") }
        startActivityForResult(i, BACKUP_CREATE)
    }
    private fun restoreBackup() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/json" }
        startActivityForResult(i, BACKUP_OPEN)
    }
    private fun createCsv() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"; putExtra(Intent.EXTRA_TITLE, "MeriZindagi-Report.csv") }
        startActivityForResult(i, CSV_CREATE)
    }

    private fun writeCsv(uri: Uri) {
        val csv = buildString {
            append("Type,Title,Details,Amount,Date,Status\n")
            load().sortedBy { it.date }.forEach { e ->
                val cells = listOf(e.type, e.title, e.detail, e.amount, dateFmt.format(Date(e.date)), if (e.done) "Done" else "Pending")
                append(cells.joinToString(",") { "\"" + it.replace("\"", "\"\"") + "\"" })
                append("\n")
            }
        }
        contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
        toast(if (isEnglish()) "CSV exported. Open it in Excel or Sheets." else "CSV एक्सपोर्ट हो गई। इसे Excel या Sheets में खोलें।")
    }

    private fun enableBiometric() {
        val manager = BiometricManager.from(this)
        val can = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (can != BiometricManager.BIOMETRIC_SUCCESS) {
            toast(if (isEnglish()) "Set up fingerprint/face unlock in phone settings first" else "पहले फोन की सेटिंग में फिंगरप्रिंट/फेस अनलॉक सेट करें")
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                prefs.edit().putBoolean("biometric_enabled", true).apply()
                render()
                toast(if (isEnglish()) "Biometric verification enabled" else "बायोमेट्रिक पुष्टि चालू हो गई")
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { toast(errString.toString()) }
            override fun onAuthenticationFailed() { toast(if (isEnglish()) "Biometric not recognized" else "फिंगरप्रिंट पहचान नहीं हुआ") }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(if (isEnglish()) "Enable MeriZindagi biometric" else "MeriZindagi बायोमेट्रिक चालू करें")
            .setSubtitle(if (isEnglish()) "Confirm with your device biometric" else "फोन के फिंगरप्रिंट या फेस से पुष्टि करें")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .setNegativeButtonText(if (isEnglish()) "Cancel" else "रद्द करें").build()
        prompt.authenticate(info)
    }

    private fun createPdf() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"; putExtra(Intent.EXTRA_TITLE, "MeriZindagi-Report.pdf") }
        startActivityForResult(i, PDF_CREATE)
    }

    private fun launchDocumentCamera() {
        try {
            val dir = File(filesDir, "documents").apply { mkdirs() }
            val file = File(dir, "camera_${System.currentTimeMillis()}.jpg")
            cameraOutputUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply { putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri); addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivityForResult(intent, TAKE_DOCUMENT_PHOTO)
        } catch (e: Exception) { toast(if (isEnglish()) "Camera could not be opened: ${e.message}" else "कैमरा नहीं खुल सका: ${e.message}") }
    }


    private fun copyDocumentToPrivateStorage(source: Uri?): Uri? {
        if (source == null) return null
        return try {
            val dir = File(filesDir, "documents").apply { mkdirs() }
            val mime = contentResolver.getType(source) ?: "application/octet-stream"
            val ext = when { mime == "application/pdf" -> ".pdf"; mime.startsWith("image/png") -> ".png"; mime.startsWith("image/webp") -> ".webp"; mime.startsWith("image/" ) -> ".jpg"; else -> ".bin" }
            val target = File(dir, "doc_${System.currentTimeMillis()}$ext")
            contentResolver.openInputStream(source)?.use { input -> FileOutputStream(target).use { output -> input.copyTo(output) } } ?: return null
            FileProvider.getUriForFile(this, "$packageName.fileprovider", target)
        } catch (_: Exception) { null }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        if (data?.data == null && requestCode != TAKE_DOCUMENT_PHOTO) return
        val uri = data?.data ?: cameraOutputUri ?: return
        try {
            when (requestCode) {
                PICK_PHOTO, TAKE_DOCUMENT_PHOTO -> {
                    val source = if (requestCode == TAKE_DOCUMENT_PHOTO) cameraOutputUri ?: uri else uri
                    val savedUri = copyDocumentToPrivateStorage(source)
                    if (savedUri == null) { toast(if (isEnglish()) "File could not be saved locally" else "फाइल फोन में सेव नहीं हो सकी"); return }
                    pendingPhotoUri = savedUri.toString()
                    val mime = contentResolver.getType(source) ?: if (source.toString().lowercase().endsWith(".pdf")) "application/pdf" else "image/*"
                    photoStatus?.text = if (isEnglish()) "Saved securely ✓  $mime" else "फोन में सुरक्षित सेव ✓  $mime"
                    if (mime.startsWith("image/")) {
                        try { photoPreview?.setImageURI(savedUri); photoPreview?.visibility = View.VISIBLE } catch (_: Exception) { photoPreview?.visibility = View.GONE }
                    } else {
                        photoPreview?.visibility = View.VISIBLE
                        photoPreview?.setImageResource(android.R.drawable.ic_menu_save)
                    }
                }
                BACKUP_CREATE -> contentResolver.openOutputStream(uri)?.use { it.write(prefs.getString("entries", "[]")!!.toByteArray()) }.also { toast(if (isEnglish()) "Backup saved" else "बैकअप सेव हो गया") }
                BACKUP_OPEN -> {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "[]"
                    org.json.JSONArray(raw)
                    prefs.edit().putString("entries", raw).apply(); ReminderScheduler.schedule(this); render(); toast(if (isEnglish()) "Backup restored" else "बैकअप वापस आ गया")
                }
                PDF_CREATE -> writePdf(uri)
                CSV_CREATE -> writeCsv(uri)
            }
        } catch (e: Exception) { toast((if (isEnglish()) "Could not complete: " else "काम पूरा नहीं हुआ: ") + (e.message ?: "")) }
    }

    private fun writePdf(uri: Uri) {
        val pdf = PdfDocument(); val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val paint = android.graphics.Paint().apply { color = Color.BLACK; textSize = 16f }
        var y = 50f; page.canvas.drawText("MeriZindagi - Life Manager Report", 40f, y, paint); y += 32f
        load().sortedBy { it.date }.forEach { e ->
            val line = "${e.type}: ${e.title} | ${dateFmt.format(Date(e.date))} | ${if (e.done) "Done" else "Pending"}"
            if (y > 800) return@forEach
            page.canvas.drawText(line.take(75), 40f, y, paint); y += 24f
        }
        pdf.finishPage(page); contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }; pdf.close(); toast(if (isEnglish()) "PDF exported" else "PDF बन गई")
    }

    private fun deletePrivateDocument(uriText: String) {
        try {
            val uri = Uri.parse(uriText)
            val filename = uri.lastPathSegment?.substringAfterLast('/') ?: return
            val file = File(File(filesDir, "documents"), filename)
            if (file.absolutePath.startsWith(File(filesDir, "documents").absolutePath)) file.delete()
        } catch (_: Exception) {}
    }

    private fun entryCard(e: Entry, compact: Boolean) = entryCardInto(body, e)

    private fun entryCardInto(parent: LinearLayout, e: Entry) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(13))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(24, 36, 59), Color.rgb(14, 22, 39))).apply { cornerRadius = dp(21).toFloat(); setStroke(dp(1), Color.rgb(48, 66, 97)) }
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val label = TextView(this).apply {
            text = when (e.type) { "बिल / EMI" -> "₹  ${if (isEnglish()) "BILL / EMI" else "बिल / EMI"}"; "दस्तावेज़" -> "▣  ${if (isEnglish()) "DOCUMENT" else "दस्तावेज़"}"; else -> "✓  ${if (isEnglish()) "FAMILY TASK" else "परिवार का काम"}" }
            textSize = 10f; setTextColor(cyan); setTypeface(null, Typeface.BOLD)
        }
        val title = TextView(this).apply {
            text = e.title; textSize = 16f; setTextColor(white); setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(4), 0, 0)
        }
        left.addView(label); left.addView(title)
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        val status = TextView(this).apply {
            text = if (e.done) (if (isEnglish()) "Done" else "पूरा") else (if (isEnglish()) "Pending" else "पेंडिंग")
            textSize = 11f; setTextColor(if (e.done) cyan else orange)
            setPadding(dp(9), dp(6), dp(9), dp(6)); background = rounded(panel2, 30)
        }
        top.addView(status)
        card.addView(top)
        if (e.photoUri.isNotBlank() && ((contentResolver.getType(Uri.parse(e.photoUri)) ?: "").startsWith("image/") || e.photoUri.lowercase().substringBefore("?").endsWith(".jpg") || e.photoUri.lowercase().substringBefore("?").endsWith(".png") || e.photoUri.lowercase().substringBefore("?").endsWith(".webp"))) {
            try {
                val thumb = ImageView(this).apply {
                    setImageURI(Uri.parse(e.photoUri)); scaleType = ImageView.ScaleType.CENTER_CROP
                    isClickable = true
                    setOnClickListener {
                        try { startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(Uri.parse(e.photoUri), if (e.photoUri.substringBefore("?").lowercase().endsWith(".pdf")) "application/pdf" else contentResolver.getType(Uri.parse(e.photoUri)) ?: when { e.photoUri.lowercase().endsWith(".jpg") || e.photoUri.lowercase().endsWith(".jpeg") -> "image/jpeg"; e.photoUri.lowercase().endsWith(".png") -> "image/png"; e.photoUri.lowercase().endsWith(".webp") -> "image/webp"; else -> "*/*" }); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
                        catch (_: Exception) { toast(if (isEnglish()) "Cannot open this image" else "यह फोटो नहीं खुल सकी") }
                    }
                }
                card.addView(thumb, LinearLayout.LayoutParams(dp(92), dp(72)).apply { topMargin = dp(8) })
            } catch (_: Exception) {}
        }
        val details = listOf(e.amount.takeIf { it.isNotBlank() }?.let { "₹ $it" },
            e.detail.takeIf { it.isNotBlank() }, e.category.takeIf { it.isNotBlank() }, e.expiryDate.takeIf { it > 0L }?.let { (if (isEnglish()) "Expires" else "एक्सपायरी") + ": " + dateFmt.format(Date(it)) }, dateFmt.format(Date(e.date))).filterNotNull().joinToString("  •  ")
        card.addView(TextView(this).apply {
            text = details; textSize = 12f; setTextColor(muted); setPadding(0, dp(8), 0, 0)
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        val doneBtn = TextView(this).apply {
            text = if (e.done) (if (isEnglish()) "Reopen" else "फिर खोलें") else (if (isEnglish()) "Mark done" else "पूरा करें"); textSize = 12f; setTextColor(cyan)
            setPadding(dp(10), dp(9), dp(10), dp(4))
            setOnClickListener {
                val updated = load().map { if (it.id == e.id) it.copy(done = !it.done) else it }
                save(updated); render()
            }
        }
        val deleteBtn = TextView(this).apply {
            text = if (isEnglish()) "Delete" else "हटाएँ"; textSize = 12f; setTextColor(0xFFFF8C9A.toInt())
            setPadding(dp(10), dp(9), dp(2), dp(4))
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage(if (isEnglish()) "Delete this entry?" else "इस एंट्री को हटाएँ?")
                    .setNegativeButton(if (isEnglish()) "Cancel" else "रद्द", null).setPositiveButton(if (isEnglish()) "Delete" else "हटाएँ") { _, _ ->
                        save(load().filterNot { it.id == e.id }); deletePrivateDocument(e.photoUri); render()
                    }.show()
            }
        }
        if (e.photoUri.isNotBlank()) {
            val openBtn = TextView(this).apply {
                text = if (isEnglish()) "Open file" else "फाइल खोलें"; textSize = 12f; setTextColor(cyan)
                setPadding(dp(10), dp(9), dp(10), dp(4))
                setOnClickListener {
                    try {
                        val uri = Uri.parse(e.photoUri)
                        val mime = if (uri.lastPathSegment?.lowercase()?.endsWith(".pdf") == true) "application/pdf" else contentResolver.getType(uri) ?: "image/*"
                        startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, mime); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) })
                    } catch (_: Exception) { toast(if (isEnglish()) "No viewer available for this file" else "इस फाइल को खोलने वाला ऐप नहीं मिला") }
                }
            }
            actions.addView(openBtn, 0)
        }
        actions.addView(doneBtn); actions.addView(deleteBtn); card.addView(actions)
        parent.addView(card, match().apply { bottomMargin = dp(9) })
    }

    private fun showAddDialog(preselected: String?) {
        val dialog = Dialog(this)
        pendingPhotoUri = ""
        photoStatus = null
        photoPreview = null
        var selectedType = preselected ?: if (isEnglish()) "Bill / EMI" else "बिल / EMI"
        var selectedCategory = if (isEnglish()) "Identity proof" else "पहचान पत्र"
        var due = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        var expiry = 0L
        val categories = if (isEnglish()) arrayOf("Identity proof", "Bank", "Insurance", "Vehicle", "Education", "Property", "Other") else arrayOf("पहचान पत्र", "बैंक", "बीमा", "वाहन", "शिक्षा", "संपत्ति", "अन्य")
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(14)); background = rounded(bg, 26) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heading = TextView(this).apply { text = if (isEnglish()) "Create new entry" else "नई एंट्री बनाएँ"; textSize = 23f; setTypeface(null, Typeface.BOLD); setTextColor(white) }
        val close = TextView(this).apply { text = "✕"; textSize = 20f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(dp(14), dp(8), dp(4), dp(8)); setOnClickListener { dialog.dismiss() } }
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f)); header.addView(close)
        outer.addView(header)
        outer.addView(TextView(this).apply { text = if (isEnglish()) "Organize bills, documents and tasks" else "बिल, दस्तावेज़ और काम व्यवस्थित करें"; textSize = 12f; setTextColor(muted); setPadding(0, dp(3), 0, dp(14)) })
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(content) }
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun sectionLabel(text: String) = TextView(this).apply { this.text = text; textSize = 12f; setTypeface(null, Typeface.BOLD); setTextColor(muted); setPadding(dp(2), dp(12), 0, dp(7)) }
        fun chip(text: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
            this.text = text; textSize = 12f; gravity = Gravity.CENTER; setPadding(dp(12), dp(10), dp(12), dp(10)); setTextColor(if (selected) Color.WHITE else muted)
            background = rounded(if (selected) Color.rgb(24, 105, 232) else panel2, 18); setOnClickListener { onClick() }
        }
        fun rowOfChips(items: List<String>, chosen: String, click: (String) -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; items.forEach { item -> addView(chip(item, item == chosen) { click(item) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) }) }
        }
        val types = if (isEnglish()) listOf("Bill / EMI", "Document", "Family task") else listOf("बिल / EMI", "दस्तावेज़", "परिवार का काम")
        val typeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun rebuildTypes() { typeRow.removeAllViews(); types.forEach { t -> typeRow.addView(chip(t, t == selectedType) { selectedType = t; rebuildTypes() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) }) } }
        rebuildTypes()
        content.addView(sectionLabel(if (isEnglish()) "ENTRY TYPE" else "एंट्री का प्रकार")); content.addView(typeRow)
        fun field(hintText: String, numeric: Boolean = false, multi: Boolean = false): EditText = EditText(this).apply {
            hint = hintText; setTextColor(white); setHintTextColor(muted); textSize = 15f; background = rounded(panel2, 16); setPadding(dp(14), dp(11), dp(14), dp(11));
            if (numeric) inputType = 2; if (!multi) setSingleLine(true)
        }
        val title = field(if (isEnglish()) "Name / title" else "नाम / शीर्षक")
        val amount = field(if (isEnglish()) "Amount (optional)" else "रकम (वैकल्पिक)", true)
        val detail = field(if (isEnglish()) "Notes / assigned to (optional)" else "नोट / किसके लिए (वैकल्पिक)", multi = true)
        content.addView(sectionLabel(if (isEnglish()) "DETAILS" else "जानकारी")); content.addView(title, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(9) }); content.addView(amount, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(9) }); content.addView(detail, LinearLayout.LayoutParams(-1, dp(66)).apply { bottomMargin = dp(6) })
        content.addView(sectionLabel(if (isEnglish()) "DOCUMENT CATEGORY" else "दस्तावेज़ श्रेणी"))
        val categoryWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun rebuildCategories() { categoryWrap.removeAllViews(); categories.toList().chunked(3).forEach { chunk -> categoryWrap.addView(LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; chunk.forEach { c -> addView(chip(c, c == selectedCategory) { selectedCategory = c; rebuildCategories() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) }) } }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) }) } }
        rebuildCategories(); content.addView(categoryWrap)
        photoStatus = TextView(this).apply { text = if (isEnglish()) "No attachment selected" else "कोई फाइल नहीं चुनी"; textSize = 12f; setTextColor(muted); setPadding(dp(2), dp(9), 0, dp(5)) }
        photoPreview = ImageView(this).apply { visibility = View.GONE; scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(panel2, 16) }
        val fileActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun actionTile(label: String, emoji: String, action: () -> Unit) = TextView(this).apply { text = "$emoji\n$label"; gravity = Gravity.CENTER; textSize = 13f; setTextColor(white); background = rounded(panel2, 18); setPadding(dp(6), dp(14), dp(6), dp(14)); setOnClickListener { action() } }
        val gallery = actionTile(if (isEnglish()) "Gallery / PDF" else "गैलरी / PDF", "▣") { val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"; putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf")); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }; startActivityForResult(pick, PICK_PHOTO) }
        val camera = actionTile(if (isEnglish()) "Camera" else "कैमरा", "📷") { launchDocumentCamera() }
        fileActions.addView(gallery, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(7) }); fileActions.addView(camera, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(sectionLabel(if (isEnglish()) "ATTACHMENT" else "फाइल / फोटो")); content.addView(fileActions); content.addView(photoStatus); content.addView(photoPreview, LinearLayout.LayoutParams(-1, dp(160)).apply { bottomMargin = dp(8) })
        val dateText = TextView(this).apply { text = (if (isEnglish()) "Date" else "तारीख") + ": ${dateFmt.format(Date(due))}"; textSize = 13f; setTextColor(white); background = rounded(panel2, 14); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val dateBtn = chip(if (isEnglish()) "Choose date" else "तारीख चुनें", false) { val c = Calendar.getInstance().apply { timeInMillis = due }; DatePickerDialog(this@MainActivity, { _, y, m, d -> c.set(y, m, d, 9, 0, 0); c.set(Calendar.MILLISECOND, 0); due = c.timeInMillis; dateText.text = "${if (isEnglish()) "Date" else "तारीख"}: ${dateFmt.format(Date(due))}" }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() }
        val expiryText = TextView(this).apply { text = if (isEnglish()) "Expiry: Not set" else "एक्सपायरी: नहीं चुनी"; textSize = 13f; setTextColor(white); background = rounded(panel2, 14); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val expiryBtn = chip(if (isEnglish()) "Set expiry (optional)" else "एक्सपायरी चुनें (वैकल्पिक)", false) { val c = Calendar.getInstance(); DatePickerDialog(this@MainActivity, { _, y, m, d -> c.set(y, m, d, 9, 0, 0); c.set(Calendar.MILLISECOND, 0); expiry = c.timeInMillis; expiryText.text = "${if (isEnglish()) "Expiry" else "एक्सपायरी"}: ${dateFmt.format(Date(expiry))}" }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() }
        content.addView(sectionLabel(if (isEnglish()) "DATES" else "तारीखें")); content.addView(dateText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }); content.addView(dateBtn, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }); content.addView(expiryText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) }); content.addView(expiryBtn, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(0, dp(12), 0, 0) }
        val cancel = chip(if (isEnglish()) "Cancel" else "रद्द करें", false) { dialog.dismiss() }
        val saveBtn = TextView(this).apply { text = if (isEnglish()) "Save entry  ✓" else "एंट्री सेव करें  ✓"; gravity = Gravity.CENTER; textSize = 14f; setTypeface(null, Typeface.BOLD); setTextColor(Color.WHITE); background = rounded(Color.rgb(24, 105, 232), 18); setPadding(dp(22), dp(13), dp(22), dp(13)); setOnClickListener {
            val name = title.text.toString().trim(); if (name.isBlank()) { toast(if (isEnglish()) "Name is required" else "नाम लिखना जरूरी है"); return@setOnClickListener }
            val type = when (selectedType) { "Bill / EMI" -> "बिल / EMI"; "Document" -> "दस्तावेज़"; "Family task" -> "परिवार का काम"; else -> selectedType }
            val list = load(); list.add(Entry(System.currentTimeMillis(), type, name, detail.text.toString().trim(), amount.text.toString().trim(), due, false, if (type == "दस्तावेज़") pendingPhotoUri else "", if (type == "दस्तावेज़") selectedCategory else "", if (type == "दस्तावेज़") expiry else 0L)); save(list); dialog.dismiss(); render(); toast(if (isEnglish()) "Saved" else "सेव हो गया")
        } }
        footer.addView(cancel, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }); footer.addView(saveBtn); outer.addView(footer)
        dialog.setContentView(outer); dialog.window?.apply { setBackgroundDrawableResource(android.R.color.transparent); setLayout((resources.displayMetrics.widthPixels * 0.96).toInt(), (resources.displayMetrics.heightPixels * 0.92).toInt()) }; dialog.show(); dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.96).toInt(), (resources.displayMetrics.heightPixels * 0.92).toInt())
    }

    private fun buildNav() {
        val items = if (isEnglish()) listOf("Home" to "⌂", "Bills" to "₹", "Docs" to "▣", "Family" to "✓", "Settings" to "☰") else listOf("होम" to "⌂", "बिल" to "₹", "दस्तावेज़" to "▣", "परिवार" to "✓", "प्रोफाइल" to "☰")
        items.forEach { (name, icon) ->
            val tabKey = if (isEnglish()) mapOf("Home" to "होम", "Bills" to "बिल", "Docs" to "दस्तावेज़", "Family" to "परिवार", "Settings" to "प्रोफाइल")[name] else name
            val active = selectedTab == name || selectedTab == tabKey
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(dp(4), dp(6), dp(4), dp(6))
                background = if (active) rounded(Color.rgb(35, 52, 80), 18) else rounded(Color.TRANSPARENT, 18)
                setOnClickListener { selectedTab = tabKey ?: name; render() }
            }
            col.addView(TextView(this).apply {
                text = icon; textSize = 21f; gravity = Gravity.CENTER
                setTextColor(if (active) cyan else muted)
            })
            col.addView(TextView(this).apply {
                text = name; textSize = 10f; gravity = Gravity.CENTER
                setTextColor(if (active) cyan else muted)
            })
            nav.addView(col, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun statCard(title: String, count: String, sub: String, accent: Int, icon: String, action: () -> Unit): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(15), dp(15), dp(13))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(25, 37, 61), Color.rgb(16, 25, 43))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), Color.rgb(49, 67, 98)) }; setOnClickListener { action() }
        }
        c.addView(TextView(this).apply { text = icon; textSize = 20f; setTextColor(accent) })
        c.addView(TextView(this).apply { text = count; textSize = 25f; setTypeface(null, Typeface.BOLD); setTextColor(white); setPadding(0, dp(3), 0, 0) })
        c.addView(TextView(this).apply { text = title; textSize = 13f; setTextColor(white) })
        c.addView(TextView(this).apply { text = sub; textSize = 10f; setTextColor(muted); setPadding(0, dp(3), 0, 0) })
        return c
    }

    private fun infoCard(title: String, desc: String) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(24, 36, 59), Color.rgb(14, 23, 40))).apply { cornerRadius = dp(21).toFloat(); setStroke(dp(1), Color.rgb(48, 66, 97)) } }
        c.addView(TextView(this).apply { text = title; textSize = 16f; setTextColor(white); setTypeface(null, Typeface.BOLD) })
        c.addView(TextView(this).apply { text = desc; textSize = 13f; setTextColor(muted); setPadding(0, dp(7), 0, 0) })
        body.addView(c, match().apply { bottomMargin = dp(10) })
    }

    private fun emptyState(title: String, desc: String) {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(28), dp(20), dp(28)); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(22, 34, 56), Color.rgb(13, 21, 38))).apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), Color.rgb(43, 61, 91)) } }
        c.addView(TextView(this).apply { text = "✦"; textSize = 28f; setTextColor(purple); gravity = Gravity.CENTER })
        c.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(white); gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD) })
        c.addView(TextView(this).apply { text = desc; textSize = 12f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
        body.addView(c, match())
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) {
        body.addView(TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        })
    }

    private fun chip(label: String, action: () -> Unit): View {
        val t = TextView(this).apply {
            text = label; textSize = 12f; gravity = Gravity.CENTER; setTextColor(white)
            background = rounded(0x334FFFFF, 30); setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { action() }
        }
        return t
    }

    private fun button(label: String, color: Int, action: () -> Unit) {
        val b = TextView(this).apply {
            text = label; textSize = 14f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(12, 19, 33)); setPadding(dp(16), dp(15), dp(16), dp(15))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(color, Color.rgb(218, 187, 117))).apply { cornerRadius = dp(17).toFloat() }
            isClickable = true; isFocusable = true; setOnClickListener { action() }
        }
        body.addView(b, match().apply { bottomMargin = dp(8) })
    }

    private fun openAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
                catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
                return
            }
        }
        Toast.makeText(this, "रिमाइंडर शेड्यूल करने की अनुमति उपलब्ध है", Toast.LENGTH_LONG).show()
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun match() = LinearLayout.LayoutParams(-1, -2)
    private fun space(v: Int) { body.addView(View(this), LinearLayout.LayoutParams(1, dp(v))) }
    private fun spaceIn(parent: LinearLayout, v: Int) { parent.addView(View(this), LinearLayout.LayoutParams(1, dp(v))) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
