MeriZindagi – Notification Update

ZIP में ये दो मुख्य फाइलें हैं:
- index.html: अपडेटेड ऐप
- sw.js: Android Chrome notification Service Worker

GitHub पर अपडेट करने के स्टेप:
1. ZIP को फोन में Extract करें।
2. GitHub में अपनी merizindagi repository खोलें।
3. Add file > Upload files दबाएँ।
4. Extract किए हुए index.html और sw.js दोनों चुनें।
5. index.html नाम की पुरानी फाइल replace करें; sw.js नई फाइल के रूप में root में आए।
6. Commit changes दबाएँ।
7. 1-3 मिनट बाद अपनी GitHub Pages वेबसाइट खोलें।
8. “नोटिफिकेशन चालू करें” दबाएँ और Allow करें।
9. “टेस्ट नोटिफिकेशन” दबाकर फोन के notification panel में देखें।

महत्वपूर्ण:
- यह GitHub Pages वेब ऐप का अपडेट है, APK नहीं।
- यह वेबसाइट खुली रहने पर हर मिनट तारीख़ जाँचती है और due date से एक दिन पहले/उसी दिन सूचना देने की कोशिश करती है।
- Chrome/वेबसाइट पूरी तरह बंद होने पर निर्धारित समय पर notification आने की गारंटी नहीं है। असली background alarms के लिए आगे native Android app या push server चाहिए।
- डेटा इसी फोन के ब्राउज़र में सेव है; browser data साफ होने पर हट सकता है।
- आधार/PAN नंबर, पासवर्ड या बैंक जानकारी ऐप में न डालें।
