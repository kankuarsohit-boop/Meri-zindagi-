package com.merizindagi.app

import android.app.*
import android.content.*
import android.os.Build
import org.json.JSONArray
import java.util.*

object ReminderScheduler {
    const val CHANNEL_ID = "merizindagi_reminders"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "MeriZindagi रिमाइंडर", NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "बिल, EMI, दस्तावेज़ और परिवार के काम"
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    fun schedule(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(context, 900, Intent(context, ReminderReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        ReminderScheduler.createChannel(context)
        val raw = context.getSharedPreferences("merizindagi_data", Context.MODE_PRIVATE).getString("entries", "[]") ?: "[]"
        val due = mutableListOf<String>()
        val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }
        val tomorrow = (today.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR,1) }
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                if (o.optBoolean("done")) continue
                val d = Calendar.getInstance().apply {
                    timeInMillis = o.optLong("date"); set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)
                }
                if (d.timeInMillis == today.timeInMillis || d.timeInMillis == tomorrow.timeInMillis)
                    due.add("${o.optString("title")} (${if (d.timeInMillis == today.timeInMillis) "आज" else "कल"})")
            }
        } catch (_: Exception) {}
        if (due.isNotEmpty()) {
            val open = PendingIntent.getActivity(context, 901, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, ReminderScheduler.CHANNEL_ID) else Notification.Builder(context)
            val n = b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("MeriZindagi रिमाइंडर")
                .setContentText(due.take(3).joinToString(" • ")).setStyle(Notification.BigTextStyle().bigText(due.joinToString("\n")))
                .setContentIntent(open).setAutoCancel(true).build()
            try { (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(9001, n) } catch (_: SecurityException) {}
        }
        ReminderScheduler.schedule(context)
    }
}
