MeriZindagi Android App - Version 3.1

Included:
- Existing Hindi/English life-manager app retained.
- Firebase Email/Password sign-in, account creation and password reset.
- Firestore sync for entries (bills/EMI, document metadata and family tasks).
- Firestore sync for language and light/dark theme settings.
- First sign-in merges local and cloud entries by entry ID before upload.
- App PIN remains local to the device and is NOT uploaded.
- Local storage remains available if cloud sync fails.

Firebase config:
- app/google-services.json is configured for project meri-zindagi-46120
- Android package: com.merizindagi.app
- Firebase Authentication Email/Password provider must be enabled.
- Firestore rules must allow each signed-in user access only to their own /users/{uid}/... path.

Important limitations:
- Username-based login is NOT implemented. Sign in uses email + password. Display name is a profile name only. Secure username login needs a trusted backend to map usernames without exposing account email addresses.
- Document photo files are NOT uploaded to Firebase Storage; local photo URIs do not automatically appear on another phone.
- Reminders are scheduled on each device; this is not a cloud push notification service.
- Premium subscriptions/payments are not enabled.
- This update does not activate Firebase billing. Do not enable a paid plan without reviewing and accepting its costs.

Cloud data path:
users/{Firebase Auth UID}/appData/main
Fields: entries (JSON string), language, lightTheme, updatedAt.

Recommended Firestore rules (Firebase Console -> Firestore Database -> Rules):
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}

Build:
1. Replace the repository ZIP named MeriZindagi-Premium-Modern-Android-v2.zip with this updated ZIP, keeping that exact filename.
2. Commit the upload to main.
3. Open Actions -> Build MeriZindagi Android APK -> Run workflow.
4. Open the newest successful green run.
5. Download the MeriZindagi-APK artifact, extract it, then install app-debug.apk.

This is source code, not a tested APK. Build and test in GitHub Actions before installing. Keep the old app and a local backup until the new APK has been tested.


UPDATE 3.2 (20-11-2026)
- Phone storage remains the primary local copy; Firestore sync remains enabled after email sign-in. Android Firestore SDK uses local cache for offline reads/writes and syncs when connected.
- Added CSV export (Excel/Google Sheets compatible) alongside PDF and JSON backup.
- Document thumbnails now open the selected image viewer when tapped.
- Added device biometric verification option using AndroidX Biometric.
- Separate Firebase email accounts can be used by different family members on the same device by signing out/in.

IMPORTANT LIMITATIONS
- This update does not create a shared multi-user family workspace, member roles, or per-member permissions. Those require a secure data model and Firestore rules migration.
- Document image files are still stored as local device URIs; they are NOT uploaded to Firebase Storage. Cloud photo backup is not included.
- Income/expense/budget, full EMI amortization, calendar and premium billing are not complete modules in this source yet. Existing bills/EMIs, documents and family tasks remain supported.
- Biometric option verifies and stores the enabled preference; app-start biometric gating is not yet wired into the launch flow. Existing PIN lock remains available.
- No local Gradle build was run while preparing this ZIP. Run the repository GitHub Actions workflow to verify the Android build before installing.


UPDATE 3.3 — ACCOUNT MANAGEMENT
- Added Add / Switch Account action in Settings. It signs out the current Firebase account and opens the existing Login / Create Account dialog.
- Added a confirmation step for logout.
- Local preferences are now separated by Firebase UID, so personal account data is not mixed on the same device.
- Existing legacy phone data is copied into the first account only if that account has no local entries yet. Existing account data is not overwritten.
- Use the same email/password to return to an account. This is account switching, not simultaneous multi-session login.

IMPORTANT FAMILY SHARING STATUS
- Shared family workspace, invite links/email, admin/member roles, and shared records are NOT enabled in this source. Do not treat the Family screen as secure shared multi-user access yet.
- These features require a deliberate Firestore schema and matching Security Rules (and ideally trusted invitation acceptance). The current per-user rules intentionally block cross-user access. Do not loosen rules to public read/write.
- This source update has not been built or tested with Gradle. Verify with GitHub Actions before installing. Keep your old app and backup.
